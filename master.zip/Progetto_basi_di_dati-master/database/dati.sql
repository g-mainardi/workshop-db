-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 30, 2022 alle 19:28
-- Versione del server: 10.4.13-MariaDB
-- Versione PHP: 7.3.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `progetto_basi_di_dati`
--

--
-- Dump dei dati per la tabella `bidoni_rifiuti_speciali`
--

INSERT INTO `bidoni_rifiuti_speciali` (`data_chiusura`, `peso`, `codBidone`) VALUES
('2022-04-20', 14.6, 1000),
('2022-04-19', 13.7, 1001),
('2022-04-15', 16.3, 1002),
(NULL, 2.2, 1003),
(NULL, 4, 1004);

--
-- Dump dei dati per la tabella `campioni`
--

INSERT INTO `campioni` (`codCampione`, `codTipo`, `CF_cliente`, `data`) VALUES
(1000, 1, 'BRGPEP65P21R889T', '2022-04-19'),
(1001, 1, 'KNTCSL89L10C990T', '2022-04-18'),
(1003, 2, 'RCIRBT90G05R443T', '2022-04-15'),
(1004, 3, 'SRCUBD70G30G556C', '2022-04-14'),
(1005, 1, 'ZGLALS82C21H778S', '2022-04-13');

--
-- Dump dei dati per la tabella `clienti`
--

INSERT INTO `clienti` (`CF`, `nome`, `cognome`, `telefono`, `data_nascita`, `luogo_nascita`, `indirizzo_residenza`, `mail`, `Medico_CF`) VALUES
('BRGPEP65P21R889T', 'peppe', 'borgia', '3428990332', '1965-10-21', 'RIMINI', 'Via san lorenzo 28', 'borgia.peppe@gmail.com', 'FLTFRC89D11C554W'),
('KNTCSL89L10C990T', 'kenneth', 'caselli', '0541892355', '1989-09-10', 'BOLOGNA', 'piazza della liberta 20', 'zeb89@gmail.com', 'SMSPTR80D05C331A'),
('PRBPOGSERAPJLKHE', 'ProvaNome', 'ProvaCognome', '3213213213', '2022-04-06', 'Rimini', 'Via Roma 1', 'prova.email@pro.va', 'FLTFRC89D11C554W'),
('RCIRBT90G05R443T', 'roberto', 'ricci', '0541652134', '1990-06-05', 'CESENA', 'via danubio 15', 'ricci.roberto@gmail.com', 'SMSPTR80D05C331A'),
('SRCUBD70G30G556C', 'ubaldo', 'sterchi', '6923125500', '1970-08-30', 'RICCIONE', 'via roma 11', 'ubaldo70@gmail.com', 'SMSPTR80D05C331A'),
('ZGLALS82C21H778S', 'alessandro', 'zagnoli', '3489087112', '1982-04-21', 'RIMINI', 'viale Garibaldi 21', 'alessandro.zagnoli@gmail.com', 'FLTFRC89D11C554W');

--
-- Dump dei dati per la tabella `controlli_mensili`
--

INSERT INTO `controlli_mensili` (`codProd_str`, `numSer_str`, `data`, `rapporto`, `esito`) VALUES
(1, '1', '2022-02-08', 'Lo strumento ha una precisione del 84 percento', '1'),
(1, '1', '2022-02-14', 'Lo strumento ha una precisione del 22 percento', '0'),
(1, '3', '2022-02-24', 'Lo strumento ha una precisione del 100 percento', '1'),
(1, '3', '2022-03-21', 'Lo strumento ha una precisione del 42 percento', '0'),
(2, '2', '2022-03-17', 'Lo strumento ha una precisione del 93 percento', '1'),
(2, '2', '2022-03-18', 'Lo strumento ha una precisione del 98 percento', '1'),
(3, '4', '2022-02-02', 'Lo strumento ha una precisione del 75 percento', '1'),
(3, '4', '2022-03-10', 'Lo strumento ha una precisione del 78 percento.', '1');

--
-- Dump dei dati per la tabella `esami`
--

INSERT INTO `esami` (`codSet`, `nome`) VALUES
(1, 'ghhfg'),
(1, 'Prolattina'),
(1, 'Testosterone libero'),
(1, 'TSH reflex'),
(2, 'Emoglobina'),
(2, 'Globuli Rossi'),
(2, 'Granulociti'),
(2, 'Linfociti'),
(2, 'Monociti'),
(2, 'Piastrine');

--
-- Dump dei dati per la tabella `esami_effettuati`
--

INSERT INTO `esami_effettuati` (`codSet`, `nome`, `codCampione`, `valore_rilevato`, `data`, `CF_tecnico`, `codProd_str`, `numSer_str`) VALUES
(2, 'Globuli Rossi', 1000, 4.5, '2022-01-20', 'FLVPOL85C20J776P', 1, '1'),
(2, 'Granulociti', 1000, 6.1, '2022-02-07', 'FLVPOL85C20J776P', 2, '2'),
(1, 'Prolattina', 1001, 1, '2022-05-10', 'FLVPOL85C20J776P', 1, '1'),
(2, 'Emoglobina', 1001, 17.2, '2022-03-15', 'FLVPOL85C20J776P', 1, '3'),
(2, 'Linfociti', 1001, 0.8, '2022-03-15', 'FLVPOL85C20J776P', 1, '3'),
(2, 'Globuli Rossi', 1003, 5.7, '2022-04-12', 'STRBRN94D21H879L', 1, '1'),
(1, 'Testosterone libero', 1004, 1.2, '2022-04-01', 'FLVPOL85C20J776P', 3, '4'),
(2, 'Linfociti', 1004, 1, '2022-04-04', 'STRBRN94D21H879L', 3, '4'),
(2, 'Piastrine', 1004, 442, '2022-04-13', 'STRBRN94D21H879L', 2, '2'),
(1, 'Prolattina', 1005, 5.6, '2022-04-22', 'FLVPOL85C20J776P', 1, '1'),
(1, 'Testosterone libero', 1005, 11, '2022-05-03', 'FLVPOL85C20J776P', 2, '2'),
(1, 'TSH reflex', 1005, 7.3, '2022-02-23', 'FLVPOL85C20J776P', 3, '4');

--
-- Dump dei dati per la tabella `fornitori`
--

INSERT INTO `fornitori` (`codFornitore`, `nome`) VALUES
(1, 'Labfor'),
(2, 'Simia'),
(3, 'SuS');

--
-- Dump dei dati per la tabella `infermieri`
--

INSERT INTO `infermieri` (`CF`, `nome`, `cognome`, `telefono`, `mail`) VALUES
('FMRALF90H17C887H', 'alfio', 'femorini', '3337070801', 'femorini.alfio@gmail.com'),
('SFRPMT94D23C998T', 'piermenti', 'sfracellozzi', '3486068614', 'piermenti94@gmail.com');

--
-- Dump dei dati per la tabella `listini`
--

INSERT INTO `listini` (`codListino`, `nome`) VALUES
(1000, 'privato'),
(1001, 'aziendale'),
(1002, 'ciao');

--
-- Dump dei dati per la tabella `lotti`
--

INSERT INTO `lotti` (`codLotto`, `data_acquisto`, `codMateriale`, `metodica`, `quantita_acquistata`, `data_scadenza`, `codFornitore`) VALUES
(1, '2022-01-11', 3000, 'MetodicaSiringaLab.pdf', 10000, '2024-01-01', 1),
(2, '2022-03-01', 1765, 'MetodicaTBR.pdf', 1000, '2022-09-01', 2),
(3, '2022-02-01', 4367, 'MetodicaGuanti.pdf', 10000, '0000-00-00', 2),
(4, '2022-05-03', 1765, 'dfsv', 2147483647, '2022-05-26', 1);

--
-- Dump dei dati per la tabella `medici`
--

INSERT INTO `medici` (`CF`, `nome`, `cognome`, `telefono`, `mail`) VALUES
('FLTFRC89D11C554W', 'gianfranco', 'folti', '541624532', 'folti.gianfranco@gmail.com'),
('SMSPTR80D05C331A', 'pietro', 'smusi', '541623135', 'pietro.smusi@gmail.com');

--
-- Dump dei dati per la tabella `necessita`
--

INSERT INTO `necessita` (`codMateriale`, `codProd_str`, `numSer_str`) VALUES
(1765, 1, '1'),
(5374, 3, '4');

--
-- Dump dei dati per la tabella `parametri`
--

INSERT INTO `parametri` (`tipo`, `codParametro`, `valore`, `unita`, `eta_min`, `eta_max`, `nome_vincolo`, `sesso`, `codSet_es`, `nome_es`) VALUES
('PARAMETRO_ORDINARIO', 1, 4.8, 'milioni/mm3', NULL, NULL, NULL, 'M', 2, 'Globuli Rossi'),
('PARAMETRO_ORDINARIO', 4, 6, 'milioni/mm3', NULL, NULL, NULL, 'M', 2, 'Globuli Rossi'),
('', 5, 150, 'migliaia/microlitro', NULL, NULL, NULL, NULL, 2, 'Piastrine'),
('', 6, 440, 'migliaia/microlitro', NULL, NULL, NULL, NULL, 2, 'Piastrine'),
('PARAMETRO_ORDINARIO', 7, 14, 'g/l', NULL, NULL, NULL, 'M', 2, 'Emoglobina'),
('PARAMETRO_ORDINARIO', 8, 18, 'g/l', NULL, NULL, NULL, 'M', 2, 'Emoglobina'),
('PARAMETRO_SPECIALE', 9, 2, 'mesi', NULL, NULL, 'Timer esplosione bomba impiantata nel cranio', 'M', 2, 'Emoglobina'),
('PARAMETRO_ORDINARIO', 10, 14, 'g/l', NULL, NULL, NULL, 'F', 2, 'Emoglobina');

--
-- Dump dei dati per la tabella `prelievi`
--

INSERT INTO `prelievi` (`CF_cliente`, `data`, `CF_infermiere`, `codListino`, `codPP`) VALUES
('BRGPEP65P21R889T', '2022-04-19', 'FMRALF90H17C887H', 1000, 1),
('KNTCSL89L10C990T', '2022-04-18', 'SFRPMT94D23C998T', 1000, 2),
('KNTCSL89L10C990T', '2022-05-10', 'FMRALF90H17C887H', 1000, 1),
('RCIRBT90G05R443T', '2022-04-15', 'FMRALF90H17C887H', 1000, 3),
('SRCUBD70G30G556C', '2022-04-14', 'SFRPMT94D23C998T', 1001, 1),
('ZGLALS82C21H778S', '2022-04-13', 'SFRPMT94D23C998T', 1001, 3);

--
-- Dump dei dati per la tabella `prezzi_esami`
--

INSERT INTO `prezzi_esami` (`codListino`, `codSet_es`, `nome_es`, `valore`) VALUES
(1000, 1, 'Testosterone libero', 10),
(1000, 1, 'TSH reflex', 8.5),
(1001, 2, 'Emoglobina', 2.5),
(1001, 2, 'Globuli Rossi', 2.5),
(1001, 2, 'Granulociti', 6),
(1000, 2, 'Linfociti', 3.5),
(1001, 2, 'Piastrine', 1.5);

--
-- Dump dei dati per la tabella `produttori`
--

INSERT INTO `produttori` (`codProduttore`, `nome`) VALUES
(1, 'Med SpA'),
(2, 'Acme SRL'),
(3, 'Krasp SRL');

--
-- Dump dei dati per la tabella `punti_prelievo`
--

INSERT INTO `punti_prelievo` (`codPP`, `via`, `CAP`, `provincia`, `civico`) VALUES
(1, 'via brombeis', '47921', 'RN', '18'),
(2, 'via flaminia', '47521', 'FC', '25'),
(3, 'via marco polo', '47121', 'FC', '21');

--
-- Dump dei dati per la tabella `revisioni_annuali`
--

INSERT INTO `revisioni_annuali` (`codProd_str`, `numSer_str`, `data`, `esito`, `rapporto`) VALUES
(1, '1', '2022-04-12', '1', 'Tutto ok.'),
(1, '3', '2022-04-12', '0', 'Rilevata perdita nel serbatoio del reagente.'),
(2, '2', '2022-02-08', '1', 'Tutto ok.'),
(3, '4', '2022-01-12', '0', 'Il macchinario Ã¨ esploso durante la revisione');

--
-- Dump dei dati per la tabella `settori_analitici`
--

INSERT INTO `settori_analitici` (`nome`, `codSet`) VALUES
('Endocrinologia', 1),
('Ematologia', 2);

--
-- Dump dei dati per la tabella `smaltimenti`
--

INSERT INTO `smaltimenti` (`codTipo`, `codBidone`) VALUES
(1, 1000),
(2, 1001),
(3, 1002);

--
-- Dump dei dati per la tabella `strumenti`
--

INSERT INTO `strumenti` (`codProduttore`, `numSeriale`, `codSet`, `nome`) VALUES
(1, '1', 2, 'Strumento'),
(1, '3', 2, 'Strumento'),
(2, '2', 1, 'Strumento'),
(3, '4', 2, 'Strumento');

--
-- Dump dei dati per la tabella `tecnici_di_laboratorio`
--

INSERT INTO `tecnici_di_laboratorio` (`CF`, `nome`, `cognome`, `telefono`, `mail`) VALUES
('FLVPOL85C20J776P', 'paolo', 'favati', '6427890324', 'favatiPaolo@gmail.com'),
('STRBRN94D21H879L', 'bruno', 'strati', '3412456998', 'brunoStrati@gmail.com');

--
-- Dump dei dati per la tabella `tipi_di_campione`
--

INSERT INTO `tipi_di_campione` (`nome`, `codTipo`) VALUES
('sanguigno', 1),
('fecale', 2),
('urinario', 3);

--
-- Dump dei dati per la tabella `tipi_di_materiale`
--

INSERT INTO `tipi_di_materiale` (`codMateriale`, `nome`, `reagente`, `materiale_sanitario`, `quantita_residua`, `quantita_di_soglia`) VALUES
(1765, 'M80-TBR', '1', '0', 0, 0),
(3000, 'Siringa', '0', '1', 8745, 0),
(4367, 'Guanti', '0', '1', 7683, 0),
(5374, 'Brefeldin', '1', '0', 1200, 0),
(6346, 'Agar', '1', '0', 93, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
