<?php
	require_once 'require.php';
    $SetParameters["titolo"] = "Prelievi";
    $SetParameters["file"] = "esami_prelievo.php";
	$templateParams["cli"] = $db->getClienti();	
    require("template/base.php");
?>
