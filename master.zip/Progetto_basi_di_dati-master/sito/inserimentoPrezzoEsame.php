<?php
    require_once 'require.php'; 

    $SetParameters["titolo"] = "Prezzi esami";
    $SetParameters["file"] = "nuovoPrezzoEsame.php";
    $SetParameters["prezzi_esami"] = $db->getPrezziEsami();
    $SetParameters["listini"] = $db->getListini();
    $SetParameters["esami"] = $db->getExams();

    if(isset($_POST["listino"])
     && ($_POST["listino"]!=0)
     && isset($_POST["settoreEsame"]) 
     && ($_POST["settoreEsame"]!=0)
     && isset($_POST["valore"]) 
     && ($_POST["valore"]!=0)
     && isset($_POST["insertPrice"])
    ){
        $setEs = explode("  -  ", ($_POST["settoreEsame"]));
        $db->insertPrezzoEsame(
        $_POST["listino"], 
        $setEs[0], 
        $setEs[1],
        $_POST["valore"]
        );
    }


    if(isset ($_POST["aggiornaValore"]) && isset ($_POST["IDlistino"]) && isset ($_POST["IDsettore"]) && isset ($_POST["nome_esame"]) && isset($_POST["VLupdate"])){
        $db->aggiornaValore($_POST["aggiornaValore"], $_POST["IDlistino"], $_POST["IDsettore"], $_POST["nome_esame"]);
    }

    require("template/base.php");
?>