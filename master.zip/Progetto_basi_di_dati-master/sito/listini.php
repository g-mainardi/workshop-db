<?php
	require_once 'require.php';
    $SetParameters["titolo"] = "Listini";
    $SetParameters["file"] = "inserimentoListini.php";
	$listini = $db->getListini();
    require("template/base.php");
?>
