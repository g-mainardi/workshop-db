$(document).ready(() => {
    $("select#vrs").change(function() {    
        let ss = $("#vrs option:selected").val();
        if (ss == "revMen") {
            $(".revMen").fadeIn();        
            $(".revAn").hide();
        } else {
            $(".revAn").fadeIn();
            $(".revMen").hide();
        }
     });
});