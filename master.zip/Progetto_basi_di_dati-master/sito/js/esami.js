$(document).ready(function() {

    $(".esami > select").change(function() {
		let tbl = $(".esami > select option:selected").val();
		$("table, form").hide();
		$(`.${tbl}`).fadeIn();
        if (tbl == "rils" || tbl == "params") {
            $("h2:last").hide();
        } else {            
            $("h2:last").fadeIn();
        }
        if (tbl == "estrack" || tbl == "esbypaz") {
            $(`table.${tbl}`).hide();
			$("h2:last").text("Esami del paziente");
            $("h2:last").hide();
            $("h2:first").text("Dati di tracciamento");
        } else {
            $("h2:first").text("Inserimento");
			$("h2:last").text("Riepilogo");
        }
 	});

	$("[name*='po_pa']").change(function() {
		let type = $("[name*='po_pa'] option:selected").val();
		if(type === "1") {
			$("#param_o").fadeIn();
			$("#param_s").hide();
			$("#nome_param").prop('required',false);
			$("#eMin_param").prop('required',true);
			$("#eMax_param").prop('required',true);
			$("#sex_param").prop('required',true);
		} else if(type === "2") {			
			$("#param_o").hide();
			$("#param_s").fadeIn();
			$("#nome_param").prop('required',true);
			$("#eMin_param").prop('required',false);
			$("#eMax_param").prop('required',false);
			$("#sex_param").prop('required',false);
		} else {			
			$("#param_o").hide();
			$("#param_s").hide();
			$("#nome_param").prop('required',false);
			$("#eMin_param").prop('required',false);
			$("#eMax_param").prop('required',false);
			$("#sex_param").prop('required',false);
		}
 	});

	$(".estrack :submit").click(function(event) {
		if(!$("table.estrack").is(":visible")) {
			$("table.estrackt").fadeOut(() => {
				$("table.estrack").fadeIn();
			});
		}
		event.preventDefault();;
		$.ajax({
			type: "POST",
			url: 'tracciaPrelievo.php',
			data: {CF_cliente: $("#CF_cliente_et").val()},
			success: function(data) {
                $("h2:last").fadeIn();
                $("h2:last").text("Esami del paziente");
                $("table.estrack").fadeIn();
				$("table.estrack tbody").children().remove();
				let val = JSON.parse(data);
				val.forEach(elem => {
					$("table.estrack tbody").append(`
						<tr>
							<td headers="nome_esame_et">${elem.nome}</td>
							<td headers="valore_esame_et">${elem.valore_rilevato}</td>
							<td headers="data_esame_et">${elem.data}</td>
							<td hidden>${elem.codCampione}</td>
							<td hidden>${elem.codSet}</td>
							<td><button type="button">Traccia</button></td>
						</tr>
					`);
				});				

				$("table.estrack button").click(function() {
					examTracking($(this));
				});
			},
			error: function(xhr, status, error){
			console.error(xhr);
			}
		});
	});

	$(".esbypaz :submit").click(function(event) {
		event.preventDefault();;
		$.ajax({
			type: "POST",
			url: 'esamiPazientiData.php',
			data: {CF: $("#cliente_ebp").val(),
				   data_inizio: $("#data_ini_ebp").val(),
				   data_fine: $("#data_fin_ebp").val()},
			success: function(data) {                
                $("h2:last").fadeIn();
                $("table.esbypaz").fadeIn();
				$("table.esbypaz tbody").children().remove();
				let val = JSON.parse(data);
				val.forEach(elem => {
					$("table.esbypaz tbody").append(`
						<tr>
							<td headers="nome_esame_ebp">${elem.nome}</td>
							<td headers="valore_esame_ebp">${elem.valore_rilevato}</td>
							<td headers="data_esame_ebp">${elem.data}</td>
						</tr>
					`);
				});				

				$("table.estrack button").click(function() {
					examTracking($(this));
				});
			},
			error: function(xhr, status, error){
			console.error(xhr);
			}
		});
	});
});

function examTracking(th) {
	$.ajax({
		type: "POST",
		url: 'tracciaEsame.php',
		data: {codSet: th.parent().siblings(":nth-last-child(2)").text(), 
			   codCampione: th.parent().siblings(":nth-last-child(3)").text(),
			   nome: th.parent().siblings(":first").text()},
		success: function(data) {
			let val = JSON.parse(data);
			$("h2:last").text("Tecnico di laboratorio");	
			$("table.estrackt tbody").children().remove();
			$("table.estrack").fadeOut(function() {
				$("table.estrackt tbody").append(`
				<tr>
					<td headers="CF_tecn_et">${val.CF}</td>
					<td headers="nome_tecn_et">${val.nome}</td>
					<td headers="cognome_tecn_et">${val.cognome}</td>
				</tr>
				`);
				$("table.estrackt").fadeIn();
			});
		},
		error: function(xhr, status, error){
		console.error(xhr);
		}
	});
}
