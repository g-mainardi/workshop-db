$(document).ready(() => {
    $("select#vps").change(function() {    
        let ss = $("#vps option:selected").val();
        if (ss == "inf") {
            $(".infer").fadeIn();        
            $(".tecn").hide();
        } else {
            $(".tecn").fadeIn();
            $(".infer").hide();
        }
     });
});