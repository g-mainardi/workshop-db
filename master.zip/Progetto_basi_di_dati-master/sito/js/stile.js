$(document).ready(() => {
    if($("main > section:first-child > *:not(a)").length == 0) {
        $("section").css("margin", "revert");
    }
});