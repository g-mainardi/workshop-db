<?php
    require_once 'require.php'; 
    $SetParameters["titolo"] = "Listini";
    $SetParameters["file"] = "listiniMenu.php";
    require("template/base.php");
?>