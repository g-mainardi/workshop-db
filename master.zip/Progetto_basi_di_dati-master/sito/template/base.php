<!DOCTYPE html>
<html lang="it">
	<head>
	<meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <script
            src="https://code.jquery.com/jquery-3.6.0.js"
            integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
            crossorigin="anonymous">
		</script>
        <script src='js/stile.js'></script>
        <?php
            if ($SetParameters["titolo"] == "Esami"){
                echo "<script src='js/esami.js'></script>";
            } elseif ($SetParameters["titolo"] == "Inserimento personale laboratorio") {
                echo "<script src='js/personale.js'></script>";
            } elseif ($SetParameters["titolo"] == "Revisioni") {				
                echo "<script src='js/revisioni.js'></script>";
			}
        ?>
		<title><?php echo $SetParameters["titolo"]?></title>
	</head>
	<body>
		<header>
			<h1><a href="index.php">PVMLAB</a></h1>
		</header>
		<main>
		<?php
		if(isset($SetParameters["file"])){
                require($SetParameters["file"]);
            }
        ?>
		</main>
		<footer>
			<ul>
				<li>
					<img src="./upload/logo.png" alt="logo" />
				</li>
				<li>
					<ul id="contacts">
						<li>
							<p>info@pvmlab.it</p>
							<p>334-1345322</p>
						</li>
						<li>
							<address>Viale dei ciliegi 24, Cesena(FC)</address>
						</li>
					</ul>
				</li>
			</ul>
		</footer>
	</body>
</html>