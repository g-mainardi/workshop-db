<section class="esami">
	<label for="vep">Visualizza: </label>
	<select id="vep">
		<option value="esame">Esame</option>
		<option value="rils">Rilevazione</option>
		<option value="setAn">Settore Analitico</option>
		<option value="params">Parametro</option>
		<option value="estrack">Traccia un esame</option>
		<option value="esbypaz">Esami di un paziente in un dato periodo</option>
	</select>
	<h2>Inserimento</h2>
	<form action="#" method="POST" class="esame">
		<ul>
			<li>
				<label for="settore_analitico">Settore Analitico:</label>
				<select name='settore_analitico' id="settore_analitico">
					<?php foreach ($templateParams["setAn"] as $setAn):?>
						<option value="<?php echo $setAn["codSet"];?>"><?php echo $setAn["nome"];?></option>
					<?php endforeach;?>
				</select>
			</li>
			<li>
				<label for="nome_esame">Nome esame:</label>
				<input type="text" id="nome_esame" name="nome_esame" placeholder="Nome esame" required/>
			</li>
		</ul>
		<input type="submit" name="submit" value="Invia" />
	</form>
	<form action="#" method="POST" class="setAn">
		<ul>
			<li>
				<label for="nome_setAn">Nome:</label>
				<input type="text" id="nome_setAn" name="nome_setAn" placeholder="Nome settore analitico" required/>
			</li>
		</ul>
		<input type="submit" name="submit" value="Invia" />
	</form>
	<form action="#" method="POST" class="rils">
		<ul>
			<li>
				<label for="nome_esame_ril">Esame:</label>
				<select name='nome_esame_ril' id="nome_esame_ril">
					<?php foreach ($templateParams["exams"] as $exm):?>
						<option value="<?php echo "{$exm['nome']}-{$exm['setID']}";?>"><?php echo "{$exm['nome']} {$exm['codSet']}";?></option>
					<?php endforeach;?>
				</select>
			</li>
			<li>
				<label for="nome_campione_ril">Campione:</label>
				<select name='nome_campione_ril' id="nome_campione_ril">
					<?php foreach ($templateParams["cpn"] as $cpn):?>
						<option value="<?php echo $cpn["codCampione"];?>"><?php echo "{$cpn['CF_cliente']} il {$cpn['data']}";?></option>
					<?php endforeach;?>
				</select>
			</li>
			<li>
				<label for="CF_tecnico_ril">Tecnico di laboratorio:</label>
				<select name='CF_tecnico_ril' id="CF_tecnico_ril">
					<?php foreach ($templateParams["tecn"] as $tec):?>
						<option value="<?php echo $tec["CF"];?>"><?php echo "{$tec['nome']} {$tec['cognome']}";?></option>
					<?php endforeach;?>
				</select>
			</li>
			<li>
				<label for="val_ril">Valore:</label>
				<input type="text" id="val_ril" name="val_ril" required/>
			</li>
			<li>
				<label for="data_ril">Data della rilevazione:</label>
				<input type="date" id="data_ril" name="data_ril" required/>
			</li>
			<li>
				<label for="str_ril">Strumento:</label>
				<select name='str_ril' id="str_ril">
					<?php foreach ($templateParams["str"] as $str):?>
						<option value="<?php echo "{$str['codProduttore']}-{$str['numSeriale']}";?>"><?php echo "{$str['nome']}-{$str['nomeProd']}";?></option>
					<?php endforeach;?>
				</select>
			</li>
		</ul>
		<input type="submit" name="submit" value="Invia" />
	</form>
	<form action="#" method="POST" class="params">
		<ul>
			<li>
				<label for="val_param">Valore:</label>
				<input type="text" id="val_param" name="val_param" required/>
			</li>
			<li>
				<label for="unit_param">Unità di misura:</label>
				<input type="text" id="unit_param" name="unit_param"  required/>
			</li>
			<li>
				<label for="nome_esame_param">Esame:</label>
				<select name='nome_esame_param' id="nome_esame_param">
					<?php foreach ($templateParams["exams"] as $exm):?>
						<option value="<?php echo "{$exm['nome']}-{$exm['setID']}";?>"><?php echo "{$exm['nome']} {$exm['codSet']}";?></option>
					<?php endforeach;?>
				</select>
			</li>
			<li>
				<label for="tipo_param">Tipo:</label>
				<select name='tipo_param' id='tipo_param'>
					<option value="0">Parametro standard</option>
					<option value="1">Parametro ordinario</option>
					<option value="2">Parametro speciale</option>
				</select>
			</li>
			<li id="param_o" hidden>
				<fieldset>
					<legend>Valori per il parametro ordinario</legend>
					<ul>
						<li>
							<label for="eMin_param">Età minima</label>
							<input type="number" id="eMin_param" min="1" max="150" name="eMin_param"/>
						</li>
						<li>
							<label for="eMax_param">Età massima:</label>
							<input type="number" id="eMax_param" min="1" max="150" name="eMax_param"/>
						</li>
						<li>
							<label for="sex_param">Sesso:</label>
							<select id="sex_param" name="sex_param">
								<option value="A">Entrambi</option>
								<option value="M">Maschio</option>
								<option value="F">Femmina</option>
							</select>
						</li>
					</ul>
				</fieldset>
			</li>
			<li id="param_s" hidden>
				<fieldset>
					<legend>Valori per il parametro speciale</legend>
					<ul>
						<li>
							<label for="nome_param">Nome parametro:</label>
							<input type="text" id="nome_param" name="nome_param"/>
						</li>
					</ul>
				</fieldset>
			</li>
		</ul>
		<input type="submit" name="submit" value="Invia" />
	</form>	
	<form action="#" method="POST" class="estrack">
		<ul>
			<li>
				<label for="CF_cliente_et">Cliente:</label>
				<select name='CF_cliente_et' id="CF_cliente_et">
					<?php foreach ($templateParams["cli"] as $cli):?>
						<option value="<?php echo $cli["CF"];?>"><?php echo "{$cli['nome']} {$cli['cognome']} {$cli['CF']}";?></option>
					<?php endforeach;?>
				</select>
			</li>
		</ul>
		<input type="submit" name="submit" value="Invia" />
	</form>	
	<form action="#" method="POST" class="esbypaz">
		<ul>
			<li>
				<label for="cliente_ebp">Cliente:</label>
				<select name='cliente_ebp' id="cliente_ebp">
					<?php foreach ($templateParams["cli"] as $cli):?>
						<option value="<?php echo $cli["CF"];?>"><?php echo "{$cli['nome']} {$cli['cognome']} {$cli['CF']}";?></option>
					<?php endforeach;?>
				</select>
			</li>
			<li>				
				<label for="data_ini_ebp">Data inizio:</label>
				<input type="date" id="data_ini_ebp" name="data_ini_ebp" required/>
			</li>
			<li>				
				<label for="data_fin_ebp">Data fine:</label>
				<input type="date" id="data_fin_ebp" name="data_fin_ebp" required/>
			</li>
		</ul>
		<input type="submit" name="submit" value="Invia" />
	</form>
	<h2>Riepilogo</h2>
	<table class="esame">
		<thead>
			<tr>
				<th id="nome_esame_v">Nome esame</th>
				<th id="codSet_esame_v">Settore analitico</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($templateParams["exams"] as $exm):?>
			<tr>
				<td headers="nome_esame_v"><?php echo $exm["nome"];?></td>
				<td headers="codSet_esame_v"><?php echo $exm["codSet"];?></td>
			</tr>
			<?php endforeach;?>
		</tbody>
	</table>	
	<table class="setAn">
		<thead>
			<tr>
				<th id="nome_setAn_v">Nome settore analitico</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($templateParams["setAn"] as $setAn):?>
			<tr>
				<td headers="nome_setAn_v"><?php echo $setAn["nome"];?></td>
			</tr>
			<?php endforeach;?>
		</tbody>
	</table>		
	<table class="estrack">
		<thead>
			<tr>
				<th id="nome_esame_et">Esame</th>
				<th id="valore_esame_et">Valore rilevato</th>
				<th id="data_esame_et">Data</th>
				<td></td>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
	<table class="estrackt">
		<thead>
			<tr>
				<th id="CF_tecn_et">CF</th>
				<th id="nome_tecn_et">Nome</th>
				<th id="cognome_tecn_et">Cognome</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>		
	<table class="esbypaz">
		<thead>
			<tr>
				<th id="nome_esame_ebp">Esame</th>
				<th id="valore_esame_ebp">Valore rilevato</th>
				<th id="data_esame_ebp">Data</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
</section>
