<section>
<a href="inserimentoCliente.php"><button type="button">CLIENTI</Button></a>
<a href="inserimentoPersonaleLab.php"><button type="button">PERSONALE LAB</Button></a>
<a href="inserimentoMedico.php"><button type="button">MEDICI</Button></a>



</section>