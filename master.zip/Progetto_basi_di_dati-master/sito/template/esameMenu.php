<section>
<a href="prelievi.php"><button type="button">PRELIEVI</button></a>    
<a href="Esami.php"><button type="button">ESAMI</Button></a>
	

</section>