<section>
<a href="listini.php"><button type="button">LISTINI</button></a>    
<a href="inserimentoPrezzoEsame.php"><button type="button">PREZZI ESAMI</Button></a>
	

</section>