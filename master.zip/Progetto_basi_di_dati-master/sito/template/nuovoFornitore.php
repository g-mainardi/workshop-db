<section>
	<h2>Inserisci un fornitore</h2>
	<form action="#" method="POST">
		<ul>
			<li>			
				<label for="nome"> Nome fornitore: </label>
				<input type="text" name="nome" placeholder="Nome fornitore" maxlength="20" required>
			</li>
		</ul>
		<input type="submit" name="submit"  value="Inserisci fornitore">
	</form>
</section>


<section>
	<h2>fornitori registrati</h2>
	<table>
		<thead>
			<tr>
				<th>CODICE FORNITORE</th><th>NOME</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["fornitori"] as $fornitore) :?>
				<tr>
					<td><?php echo $fornitore["codFornitore"]?></td><td><?php echo $fornitore["nome"]?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>