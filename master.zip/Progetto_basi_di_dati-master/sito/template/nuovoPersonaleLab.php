<section class="l100">
    <label for="vps">Visualizza: </label>
    <select id="vps">
        <option value="tecn">Tecnici</option>
        <option value="inf">Infermieri</option>
    </select>
</section>

<section class="tecn">
    <h2>Registra un tecnico</h2>
	<form action="#" method="POST">
		<ul>
			<li>			
				<label for="CFTecnico"> Codice fiscale: </label>
				<input type="text" id="CFTecnico" name="CFTecnico" placeholder="Codice fiscale" maxlength="16" required>
			</li>
			<li>			
				<label for="nome"> Nome: </label>
				<input type="text" id="nome" name="nomeTecnico" placeholder="Nome tecnico" maxlength="20" required>
			</li>
			<li>			
				<label for="cognomeTecnico"> Cognome: </label>
				<input type="text" id="cognomeTecnico" name="cognomeTecnico" placeholder="Cognome tecnico" maxlength="20" required>
			</li>
			<li>			
				<label for="telefonoTecnico"> Telefono: </label>
				<input type="tel" id="telefonoTecnico" pattern="[0-9]{10}" maxlength="10" name="telefonoTecnico" placeholder="Telefono tecnico">
			</li>
			<li>			
				<label for="mailTecnico"> Email: </label>
				<input type="email" id="mailTecnico" name="mailTecnico" placeholder="Email" maxlength="80">
			</li>
		</ul>
		<input type="submit" name="submit"  value="Inserisci tecnico">
	</form>
</section>


<section class="tecn">
	<h2>tecnici registrati</h2>
	<table>
		<thead>
			<tr>
				<th>CF</th><th>NOME</th><th>COGNOME</th><th>TELEFONO</th><th>MAIL</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["tecnici_di_laboratorio"] as $tecnico) :?>
				<tr>
					<td><?php echo $tecnico["CF"]?></td><td><?php echo $tecnico["nome"]?></td><td><?php echo $tecnico["cognome"]?></td><td><?php echo $tecnico["telefono"]?></td><td><?php echo $tecnico["mail"]?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>

	</table>
</section>

<section class="infer">
    <h2>Registra un infermiere</h2>
	<form action="#" method="POST">
		<ul>
			<li>			
				<label for="CFInfermiere"> Codice fiscale: </label>
				<input id="CFInfermiere" type="text" name="CFInfermiere" placeholder="Codice fiscale" maxlength="16" required>
			</li>
			<li>			
				<label for="nomeInfermiere"> Nome: </label>
				<input type="text" id="nomeInfermiere" name="nomeInfermiere" placeholder="Nome infermiere" maxlength="20" required>
			</li>
			<li>			
				<label for="cognomeInfermiere"> Cognome: </label>
				<input type="text" id="cognomeInfermiere" name="cognomeInfermiere" placeholder="Cognome infermiere" maxlength="20" required>
			</li>
			<li>			
				<label for="telefonoInfermiere"> Telefono: </label>
				<input type="tel" pattern="[0-9]{10}" maxlength="10" id="telefonoInfermiere" name="telefonoInfermiere" placeholder="Telefono infermiere">
			</li>
			<li>			
				<label for="mailInfermiere"> Email: </label>
				<input type="email" id="mailInfermiere" name="mailInfermiere" placeholder="Email" maxlength="80">
			</li>
		</ul>
		<input type="submit" name="submit"  value="Inserisci infermiere">
	</form>
</section>


<section class="infer">
	<h2>infermieri registrati</h2>
	<table>
		<thead>
			<tr>
				<th>CF</th><th>NOME</th><th>COGNOME</th><th>TELEFONO</th><th>MAIL</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["infermieri"] as $infermiere) :?>
				<tr>
					<td><?php echo $infermiere["CF"]?></td><td><?php echo $infermiere["nome"]?></td><td><?php echo $infermiere["cognome"]?></td><td><?php echo $infermiere["telefono"]?></td><td><?php echo $infermiere["mail"]?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>
