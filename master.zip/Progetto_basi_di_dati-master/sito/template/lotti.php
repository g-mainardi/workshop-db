<section>
	<h2>Inserisci un lotto</h2>
	<form action="#" method="POST">
        <ul>
            <li>
                <label for="dataAcquisto"> data acquisto: </label>
                <input type="date" id="dataAcquisto" name="dataAcquisto" required>
            </li>
            <li>
                <label for="IDmateriale">materiale: </label>
                <select name='IDmateriale' id="IDmateriale">
                    <option value="0" selected> Seleziona il materiale </option>
                    <?php
                        foreach($SetParameters["tipi_di_materiale"] as $materiale):
                    ?>
                    <option value="<?php echo $materiale['codMateriale']?>"> <?php echo $materiale['nome']?> </option>
                    <?php 
                        endforeach;
                    ?>
                </select>
            </li>
            <li>
                <label for="metodica"> metodica: </label>
                <input type="text" id="metodica" name="metodica" placeholder="metodica" maxlength="20" required>
            </li>
            <li>
                <label for="quantita"> quantita acquistata: </label>
                <input type="number"  min="1" step="1" name="quantita" id="quantita" placeholder="quantita acquistata" required>
            </li>
            <li>
                <label for="dataScadenza"> data scadenza: </label>
                <input type="date" id="dataScadenza" name="dataScadenza" required>
            </li>
            <li>
                <label for="IDfornitore">fornitore: </label>
                <select name='IDfornitore' id="IDfornitore">
                    <option value="0" selected> Seleziona il fornitore </option>
                    <?php
                        foreach($SetParameters["fornitori"] as $fornitore):
                    ?>
                    <option value="<?php echo $fornitore['codFornitore']?>"> <?php echo $fornitore['nome']?> </option>
                    <?php 
                        endforeach;
                    ?>
                </select>
            </li>
        </ul>
		<input type="submit" name="submit"  value="Inserisci lotto">
	</form>    
</section>
<section>
    <h2>Lotti registrati</h2>
    <table>
		<thead>
			<tr>
				<th>CODICE LOTTO</th><th>DATA ACQUISTO</th><th>CODICE MATERIALE</th><th>METODICA</th><th>QUANTITA ACQUISTATA</th><th>DATA SCADENZA</th><th>CODICE FORNITORE</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["lotti"] as $lotto):?>
			<tr>
				<td><?php echo $lotto["codLotto"]?></td>
				<td><?php echo $lotto["data_acquisto"]?></td>
				<td><?php echo $lotto["nome_materiale"]?></td>
				<td><?php echo $lotto["metodica"]?></td>
				<td><?php echo $lotto["quantita_acquistata"]?></td>
				<td><?php echo $lotto["data_scadenza"]?></td>
				<td><?php echo $lotto["nome_fornitore"]?></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
    </table>
</section>

