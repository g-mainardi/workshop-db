<section>
	<h2>Inserisci un materiale</h2>
	<form action="#" method="POST">
        <ul>
            <li>
                <label for="nome"> Nome materiale: </label>
                <input type="text" name="nome" placeholder="Nome materiale" maxlength="20" required>
            </li>
            <li>
                <label for="quantita"> quantita materiale: </label>
                <input type="num" min="1" step="1"  name="quantita" placeholder="Quantita materiale" maxlength="11" required>
            </li>
			<li>
                <label for="soglia"> quantita di soglia: </label>
                <input type="num" min="1" step="1"  name="soglia" placeholder="Quantita di soglia" maxlength="11" required>
            </li>
            <fieldset>
                <legend>Tipo materiale</legend>
                <ul>
                    <li>
                        <label for="reagente"> reagente: </label>
                        <input type="radio" name="tipo_materiale" value="reagente" checked="checked">
                    </li>
                    <li>
                        <label for="materiale_sanitario">materiale sanitario</label>
                        <input type="radio" name="tipo_materiale" value="materiale_sanitario">
                    </li>
                </ul>
            </fieldset>
        </ul>
        <input type="submit" name="submit"  value="Inserisci materiale" />
	</form>
</section>


<section>
	<h2>Materiale in laboratorio</h2>
	<table>
		<thead>
			<tr>
				<th>CODICE MATERIALE</th><th>NOME</th><th>REAGENTE</th><th>MATERIALE SANITARIO</th><th>QUANTITA RESIDUA</th><th>QUANTITA DI SOGLIA</th><th colspan="2">AGGIORNA QUANTITA</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["tipi_di_materiale"] as $materiale) :?>
				<tr>
					<td><?php echo $materiale["codMateriale"]?></td><td><?php echo $materiale["nome"]?></td><td><?php  if ($materiale["reagente"]==1) {echo "si";} else{echo"no";}?></td><td><?php if ($materiale["materiale_sanitario"]==1) {echo "si";} else{echo"no";}?></td><td><?php echo $materiale["quantita_residua"]?></td><td><?php echo $materiale["quantita_di_soglia"]?></td>
					<td>
						<form action="#" method="POST">
							<input type="num" name="aggiornaQuantita" placeholder="aggiorna quantita"  min="1" step="1" maxlength="20" required>	
					</td>
					<td>
							<input type="hidden" name="IDmateriale" value="<?php echo $materiale["codMateriale"]?>" />
							   <input type="submit" name="submit"  value="aggiorna">
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>






<section>
	<h2>MATERIALI IN ESAURIMENTO</h2>
	<table>
		<thead>
			<tr>
				<th>CODICE MATERIALE</th><th>NOME</th><th>REAGENTE</th><th>MATERIALE SANITARIO</th><th>QUANTITA RESIDUA</th><th>QUANTITA DI SOGLIA</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["materialiEsauriti"] as $materiale) :?>
				<tr>
					<td><?php echo $materiale["codMateriale"]?></td><td><?php echo $materiale["nome"]?></td><td><?php  if ($materiale["reagente"]==1) {echo "si";} else{echo"no";}?></td><td><?php if ($materiale["materiale_sanitario"]==1) {echo "si";} else{echo"no";}?></td><td><?php echo $materiale["quantita_residua"]?></td><td><?php echo $materiale["quantita_di_soglia"]?></td>
				</tr>	
			<?php endforeach; ?>
		</tbody>
	</table>
</section>