<section>
	<h2>Inserisci un nuovo strumento</h2>
	<form action="#" method="POST">
		<ul>
          <li>
				<label for="produttore">Produttore: </label>
				<select name='produttore'>
					<option value="0" selected> Seleziona il produttore </option>
					<?php
						foreach($SetParameters["produttori"] as $produttore):
					?>
					<option value="<?php echo $produttore['codProduttore']?>"> <?php echo $produttore['nome']?> </option>
					<?php 
						endforeach;
					?>
				</select>
			</li>

			<li>			
				<label for="seriale"> Numero seriale: </label>
				<input type="text" name="seriale" placeholder="Numero seriale" maxlength="20" required>
			</li>

            <li>
				<label for="settore">Settori analitici: </label>
				<select name='settore'>
					<option value="0" selected> Seleziona il settore analitico </option>
					<?php
						foreach($SetParameters["settori_analitici"] as $settore):
					?>
					<option value="<?php echo $settore['codSet']?>"> <?php echo $settore['nome']?> </option>
					<?php 
						endforeach;
					?>
				</select>
			</li>

			<li>			
				<label for="nome"> Nome strumento: </label>
				<input type="text" name="nome" placeholder="nome strumento" maxlength="20" required>
			</li>

		</ul>
		<input type="submit" name="submit"  value="Inserisci strumento">
	</form>
</section>


<section>
	<h2>Strumenti</h2>
	<table>
		<thead>
			<tr>
				<th>PRODUTTORE</th><th>NUMERO SERIALE</th><th>SETTORE ANALITICO</th><th>NOME STRUMENTO</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["strumenti"] as $strumento) :?>
				<tr>
					<td><?php echo $strumento["nome_produttore"]?></td><td><?php echo $strumento["numSeriale"]?></td><td><?php echo $strumento["nome_settore"]?></td><td><?php echo $strumento["nome"]?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>
