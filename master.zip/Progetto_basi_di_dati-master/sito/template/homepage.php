<section>
	<a href="anagrafica.php"><button type="button">ANAGRAFICA</Button></a>
	<a href="SelezioneEsami.php"><button type="button">ESAMI</button></a>
	<a href="magazzino.php"><button type="button">MAGAZZINO</button></a>
	<a href="stat.php"><button type="button">STATISTICHE</button></a>
	<a href="bidoni.php"><button type="button">RIFIUTI</button></a>
	<a href="menuListini.php"><button type="button">LISTINI</button></a>
	<a href="strumentazione.php"><button type="button">STRUMENTAZIONE</button></a>
</section>