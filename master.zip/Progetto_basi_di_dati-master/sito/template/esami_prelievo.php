<?php
	require_once 'require.php';
	//$exams;
	if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET) && sizeof($_GET) > 0){
		if(!isset($_GET['customerCF']) || strlen($_GET['customerCF']) != 16)
			echo "Codice fiscale sbagliato";
		elseif(!isset($_GET['customerspecimendate']) || !$_GET['customerspecimendate']){
			echo "Inserire la data del prelievo";
		}
		else{
			$exams = $db->getEsamiFromPrelievo($_GET['customerspecimendate'], $_GET["customerCF"]);
			$inf = $db->getInfermiereFromPrelievo($_GET["customerCF"], $_GET['customerspecimendate']);
		}
	}
?>
<section>
	<h2>Ricerca esami per prelievo</h2>
	<form name="esami_prelievi_form" action="<?php echo $_SERVER["PHP_SELF"];?>" method="GET">
		<ul>
			<li>
				<label for="customerCF">Cliente: </label>
				<select name="customerCF" id="customerCF">            
					<?php foreach ($templateParams["cli"] as $cli):?>
						<option value="<?php echo $cli["CF"];?>"><?php echo "{$cli['nome']} {$cli['cognome']} {$cli['CF']}";?></option>
					<?php endforeach;?>
				</select>
			</li>
			<li>
				<label for="customerspecimendate">Data prelievo: </label>
				<input type="date" id="customerspecimendate" name="customerspecimendate">
			</li>
		</ul>
		<input type="submit" id="BTNSubmit" value="Cerca esami">
	</form>

<?php
	if($_GET):
		if(!isset($exams) || sizeof($exams) <= 0):
	?>
		Non sono stati trovati esami con quella combinazione
	<?php
		else:
			echo "<p>Infermiere che ha effettuato il prelievo: <strong>" . $inf[0]['cognome'] . " " . $inf[0]['nome'] . " (" . $inf[0]['CF'] . ")</strong></p>";
			foreach($exams as $e):
			$examParameters = $db->getParametroOrdinario($e['codiceSettore'], $e['nome']);
			
			if(!isset($lastExamType) || $lastExamType != $e['nomeSettore']):
				if(isset($lastExamType)){
					echo "</table>";
				}
	?>
		<table>
		<caption> <?php echo $e['nomeSettore'] ?> </caption>
		<thead>
			<tr>
				<th> Nome esame </th>
				<th> Valore rilevato </th>
				<th> Parametri ideali </th>
			</tr>
		</thead>
	<?php
			endif;
			$minMax = "";
			$min = "No min";
			$max = "No max";
			
			if (sizeof($examParameters) > 0){
				foreach($examParameters as $eP){
					if(!isset($sesso) || $sesso != $eP['sesso']){
						if($min != "No min" || $max != "No max") {
							$minMax .= $min .' - '. $max . ' (' . $examParameters[0]['unita'] . ') (' . $sesso . ')';
						}
						$minMax .= '<br />';
						$min = "No min";
						$max = "No max";
						unset($sesso);
					}
					$sesso = $eP['sesso'];
					if(is_numeric($max) && intval($eP['valore']) > intval($max)){
						$min = $max;
						$max = $eP['valore'];
					} else {
						$max = $eP['valore'];
					}
				}
				if($min != "No min" || $max != "No max") {
					$minMax .= $min .' - '. $max . ' (' . $examParameters[0]['unita'] . ') (' . $sesso . ')';
				}
			}
			
			$examSpecialParameters = $db->getParametroNonOrdinario($e['codiceSettore'], $e['nome']);
	?>
			<tr>
				<td> <?php echo $e['nome']; ?> </td>
				<td> <?php echo $e['valore_rilevato']; ?> </td>
				<td> <?php echo $minMax; 
				$p = '';
					foreach($examSpecialParameters as $specialParam){
						$p .= '<br />' . $specialParam['nome_vincolo'] . ": " . $specialParam['valore'] . " " . $specialParam['unita'];
					}
				if(strlen($p) > 0){
					echo $p;
				}
				?> </td>
			</tr>
	<?php
			$lastExamType = $e['nomeSettore'];
			endforeach;
			echo "</table>";
		endif;
	endif;
?>
</section>