<section>
	<h2>Inserimento nuovo listino</h2>
	<form name="listino" action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST">
		<ul>
			<li>
				<label for="nomeListino"> Nome listino: </label>
				<input type="text" name="nomeListino" id="nomeListino"/>
			</li>
		</ul>
	<input type="submit" name="BTNSubmit" value="Inserisci">
	</form>
</section>
<section>
	<h2>Elenco listini disponibili</h2>
	<table>
        <thead>
            <tr>
                <th> Nome listino </th>
            </tr>
        </thead>
        <tbody>
            <?php
                foreach($listini as $l):
            ?>
            <tr> <td> <?php echo $l['nome']; ?> </td> </tr>
            <?php
                endforeach;
            ?>
        </tbody>
	</table>
</section>

<?php

	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST) && sizeof($_POST) > 0){
		if(isset($_POST['nomeListino']) && strlen($_POST['nomeListino']) > 0){
			$checkListino = $db->getListinoByName($_POST['nomeListino']);
			if(sizeof($checkListino) == 0){
				$db->insertListino($_POST['nomeListino']);
			} else {
				echo "Esiste già un listino con quel nome";
			}
		} else {
			echo "Devi assegnare un nome al listino";
		}
	}

?>
