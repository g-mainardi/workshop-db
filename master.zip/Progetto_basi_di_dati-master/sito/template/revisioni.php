<section class="l100">
    <label for="vrs">Visualizza: </label>
    <select id="vrs">
        <option value="revMen">Revisione Mensile</option>
        <option value="revAn">Revisione Annuale</option>
    </select>
</section>

<section class="revMen">
	<h2>Inserimento revisioni mensili</h2>
	<form action="#" method="POST">
		<ul>
        	<li>
				<label for="seriale">Strumento: </label>
				<select name='seriale'>
					<option value="0" selected> seleziona il produttore e numero seriale</option>
					<?php
						foreach($SetParameters["strumenti"] as $strumento):
					?>
					<option value="<?php echo $strumento['codProduttore'] ."  -  ". $strumento['numSeriale']; ?>"> <?php echo $strumento['nome_produttore'] ."  -  ". $strumento['numSeriale'];?> </option>
					<?php 
						endforeach;
					?>
				</select>
			</li>
            <li>			
				<label for="data"> data: </label>
				<input type="date" name="data" required>
			</li>
            <li>			
				<label for="rapporto"> rapporto: </label>
				<input type="text" name="rapporto" required>
			</li>
            <li>
				<label for="esito">selezione l'esito, 1 positivo e 0 negativo: </label>
				<select name='esito'>
					<option value="0">0</option>
                    <option value="1">1</option>

				</select>
			</li>
		</ul>
		<input type="submit" name="mensile"  value="Inserisci strumento">
	</form>
</section>

<section class="revMen">
	<h2>strumenti</h2>
	<table>
		<thead>
			<tr>
				<th>PRODUTTORE</th><th>NUMERO SERIALE</th><th>SETTORE ANALITICO</th><th>PRECISIONE</th><th>ESITO</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["controlli_mensili"] as $mensile) :?>
				<tr>
					<td><?php echo $mensile["nome_produttore"]?></td><td><?php echo $mensile["numSer_str"]?></td><td><?php echo $mensile["data"]?></td><td><?php echo $mensile["rapporto"]?></td>
					<td><?php  if ($mensile["esito"]==1) {echo "positivo";} else{echo"negativo";}?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>

<section class="revMen">
	<h2>strumenti che non hanno passato il controllo mensile</h2>
	<table>
		<thead>
			<tr>
				<th>PRODUTTORE</th><th>NUMERO SERIALE</th><th>SETTORE ANALITICO</th><th>PRECISIONE</th><th>ESITO</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["cont_mens_nonPassate"] as $mensile) :?>
				<tr>
					<td><?php echo $mensile["nome_produttore"]?></td><td><?php echo $mensile["numSer_str"]?></td><td><?php echo $mensile["data"]?></td><td><?php echo $mensile["rapporto"]?></td>
					<td><?php  if ($mensile["esito"]==1) {echo "positivo";} else{echo"negativo";}?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>

<section class="revAn">	
	<h2>Inserimento revisioni annuali</h2>
	<form action="#" method="POST">
		<ul>

        <li>
				<label for="seriale">Strumento: </label>
				<select name='seriale'>
					<option value="0" selected> seleziona il produttore e numero seriale</option>
					<?php
						foreach($SetParameters["strumenti"] as $strumento):
					?>
					<option value="<?php echo $strumento['codProduttore'] ."  -  ". $strumento['numSeriale']; ?>"> <?php echo $strumento['nome_produttore'] ."  -  ". $strumento['numSeriale'];?> </option>
					<?php 
						endforeach;
					?>
				</select>
			</li>

            <li>			
				<label for="data"> data: </label>
				<input type="date" name="data" required>
			</li>

            <li>			
				<label for="rapporto"> rapporto: </label>
				<input type="text" name="rapporto" required>
			</li>

            <li>
				<label for="esito">selezione l'esito, 1 positivo e 0 negativo: </label>
				<select name='esito'>
					<option value="0">0</option>
                    <option value="1">1</option>

				</select>
			</li>


		</ul>
		<input type="submit" name="annuale"  value="Inserisci strumento">
	</form>
</section>


<section class="revAn">
	<h2>strumenti</h2>
	<table>
		<thead>
			<tr>
				<th>PRODUTTORE</th><th>NUMERO SERIALE</th><th>SETTORE ANALITICO</th><th>RAPPORTO</th><th>ESITO</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["revisioni_annuali"] as $annuale) :?>
				<tr>
					<td><?php echo $annuale["nome_produttore"]?></td><td><?php echo $annuale["numSer_str"]?></td><td><?php echo $annuale["data"]?></td><td><?php echo $annuale["rapporto"]?></td>
					<td><?php  if ($annuale["esito"]==1) {echo "positivo";} else{echo"negativo";}?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>


<section class="revAn">
	<h2>strumenti che non hanno passato la revisione annuale</h2>
	<table>
		<thead>
			<tr>
				<th>PRODUTTORE</th><th>NUMERO SERIALE</th><th>SETTORE ANALITICO</th><th>RAPPORTO</th><th>ESITO</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["rev_ann_nonPassate"] as $annuale) :?>
				<tr>
					<td><?php echo $annuale["nome_produttore"]?></td><td><?php echo $annuale["numSer_str"]?></td><td><?php echo $annuale["data"]?></td><td><?php echo $annuale["rapporto"]?></td>
					<td><?php  if ($annuale["esito"]==1) {echo "positivo";} else{echo"negativo";}?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>