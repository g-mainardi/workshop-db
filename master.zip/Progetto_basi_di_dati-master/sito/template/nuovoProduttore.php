<section>
	<h2>Inserisci un produttore</h2>
	<form action="#" method="POST">
		<ul>
			<li>			
				<label for="nome"> Nome produttore: </label>
				<input type="text" name="nome" placeholder="Nome produttore" maxlength="20" required>
			</li>
		</ul>
		<input type="submit" name="submit"  value="Inserisci produttore">
	</form>
</section>


<section>
	<h2>Produttori registrati</h2>
	<table>
		<thead>
			<tr>
				<th>CODICE PRODUTTORE</th><th>NOME</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["produttori"] as $produttore) :?>
				<tr>
					<td><?php echo $produttore["codProduttore"]?></td><td><?php echo $produttore["nome"]?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>