<section>
	<h2>Registra un cliente</h2>
	<form action="#" method="POST">
		<ul>
			<li>
				<label for="clienteCF"> Codice fiscale cliente: </label>
				<input type="text" name="clienteCF" placeholder="Codice fiscale" maxlength="16" required>
			</li>
			<li>				
				<label for="clienteNome"> Nome cliente: </label>
				<input type="text" name="clienteNome" placeholder="Nome paziente" maxlength="20" required>
			</li>
			<li>
				<label for="clienteCognome"> Cognome cliente: </label>
				<input type="text" name="clienteCognome" placeholder="Cognome paziente" maxlength="20" required>
			</li>
			<li>				
				<label for="clienteTelefono"> Telefono cliente: </label>
				<input type="tel" pattern="[0-9]{10}" maxlength="10" name="clienteTelefono" placeholder="Telefono paziente">
			</li>
			<li>				
				<label for="clienteDataNascita"> Data di nascita: </label>
				<input type="date" name="clienteDataNascita">
			</li>
			<li>				
				<label for="clienteLuogoNascita"> Città di nascita: </label>
				<input type="text" name="clienteLuogoNascita" placeholder="Città di nascita" maxlength="20" required>
			</li>
			<li>				
				<label for="clienteIndirizzo"> Indirizzo di residenza: </label>
				<input type="text" name="clienteIndirizzo" placeholder="Indirizzo" maxlength="80" required>
			</li>
			<li>				
				<label for="clienteMail"> Email: </label>
				<input type="email" name="clienteMail" placeholder="Email" maxlength="80">
			</li>
			<li>
				<label for="dottore">Medico: </label>
				<select name='dottore'>
					<option value="0" selected> Seleziona il medico curante </option>
					<?php
						foreach($SetParameters["medici"] as $medico):
					?>
					<option value="<?php echo $medico['CF']?>"> <?php echo $medico['cognome'] . " " . $medico['nome'];?> </option>
					<?php 
						endforeach;
					?>
				</select>
			</li>
		</ul>		
		<input type="submit" name="submit"  value="Inserisci cliente">
	</form>

</section>

<section>
	<h2>clienti registrati</h2>
	<table>
		<thead>
			<tr>
				<th>CF</th><th>NOME</th><th>COGNOME</th><th>TELEFONO</th><th>DATA DI NASCITA</th><th>LUOGO DI NASCITA</th><th>INDIRIZZO RESIDAENZA</th><th>MAIL</th><th>CF MEDICO</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["clienti"] as $cliente) :?>
			<tr>
				<td><?php echo $cliente["CF"]?></td><td><?php echo $cliente["nome"]?></td><td><?php echo $cliente["cognome"]?></td><td><?php echo $cliente["telefono"]?></td>
				<td><?php echo $cliente["data_nascita"]?></td><td><?php echo $cliente["luogo_nascita"]?></td><td><?php echo $cliente["indirizzo_residenza"]?></td>
				<td><?php echo $cliente["mail"]?></td><td><?php echo $cliente["Medico_CF"]?></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>
