<section>
    <fieldset>
        <legend>inserimento nuovo prelievo</legend>
        <label for="CF_cliente">CF cliente</label>
        <input type="text" id="CF_cliente" name="CF_cliente">

        <label for="data">data prelievo</label>
        <input type="date" id="data" name="data">

        <label for="CF_infermiere">CF infermiere</label>
        <input type="text" id="CF_infermiere" name="CF_infermiere">

        <label for="codListino">codice listino prezzi</label>
        <input type="text" id="codListino" name="codListino">

        <label for="codPP">codice punto prelievo</label>
        <input type="text" id="codPP" name="codPP">
        
        
    </fieldset>
</section>