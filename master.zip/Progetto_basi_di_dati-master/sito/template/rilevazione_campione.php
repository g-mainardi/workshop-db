<?php
	require_once '../utilities/functions.php';
	require_once '../require.php';
	$connection = connect();
	
	$query = $connection->prepare('SELECT CF, nome, cognome FROM tecnici_di_laboratorio');
	$query->execute();
	$result = $query->get_result();
	$techs = $result->fetch_all(MYSQLI_ASSOC);
	
	$query = $connection->prepare('SELECT codCampione from campioni ORDER BY codCampione DESC');
	$query->execute();
	$result = $query->get_result();
	$specimen = $result->fetch_all(MYSQLI_ASSOC);
	
	$query = $connection->prepare('SELECT * FROM esami');
	$query->execute();
	$result = $query->get_result();
	$exams = $result->fetch_all(MYSQLI_ASSOC);
	
	$query = $connection->prepare('SELECT codProduttore, numSeriale, settori_analitici.nome FROM strumenti JOIN settori_analitici ON strumenti.codSet = settori_analitici.codSet');
	$query->execute();
	$result = $query->get_result();
	$analytic = $result->fetch_all(MYSQLI_ASSOC);
	
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if($_POST['specimenCode'] == "0" || $_POST['examName'] == "0" || $_POST['techName'] == "0" || $_POST['machineName'] == "0"){
			echo "Devi selezionare tutti i parametri richiesti";
		} else {
			$machine = explode("_", $_POST['machineName']);
			$machineProd = $machine[0];
			$machineSerial = $machine[1];
			
			$ex = explode("_", $_POST['examName']);
			$codSet = $ex[0];
			$exName = $ex[1];

			$query = $connection->prepare('INSERT INTO esami_effettuati (codSet, nome, codCampione, valore_rilevato, data, CF_tecnico, codProd_str, numSer_str) VALUES (?, ?, ?, ?, ?, ?, ?, ?); ');
			$query->bind_param("isiissss", $codSet, $exName, $_POST['specimenCode'], $_POST['value'], $_POST['testDate'], $_POST['techName'], $machineProd, $machineSerial);
			$query->execute();
			if($query){
				echo "Inserimento avvenuto con successo";
				echo "<meta http-equiv='refresh' content='0'>";
				
			} else {
				echo "L'inserimento non è stato effettuato. Potrebbe già essere stata inserita una rilevazione dello stesso esame sul campione, oppure hai inserito uno strumento che appartiene ad un settore analitico diverso rispetto a quello dell'esame effettuato";
			}
		}
	}
?>

<!DOCTYPE html>
<html lang='it'>
	<head>
		<link rel="shortcut icon" type="image/ico" href="img/favicon.ico">
		<title> Nuovo cliente - Laboratorio Analisi </title>
	</head>
	<body>
	<form name="newcustomerform" action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST">
		<label for="specimenCode"> Codice campione: </label>
		<select name='specimenCode'>
			<option value="0" selected> Seleziona il campione </option>
			<?php
				foreach($specimen as $s):
			?>
			<option value="<?php echo $s['codCampione']?>"> <?php echo $s['codCampione'];?> </option>
			<?php 
				endforeach;
			?>
		</select>
		<label for="examName"> Nome esame </label>
		<select name='examName'>
			<option value="0" selected> Seleziona l'esame </option>
			<?php
				foreach($exams as $e):
			?>
			<option value="<?php echo $e['codSet'] . '_' . $e['nome']; ?>"> <?php echo $e['nome'];?> </option>
			<?php 
				endforeach;
			?>
		</select>
		<label for="value"> Valore rilevato </label>
		<input type="numeric" name="value" required>
		<label for="testDate"> Data rilevazione </label>
		<input type="date" name="testDate"  required>
		<label for="techName"> Codice Fiscale tecnico </label>
		<select name='techName'>
			<option value="0" selected> Seleziona il tecnico </option>
			<?php
				foreach($techs as $t):
			?>
			<option value="<?php echo $t['CF']?>"> <?php echo $t['CF']  . ' - ' . $t['cognome'] . " " . $t['nome'];?> </option>
			<?php 
				endforeach;
			?>
		</select>
		<label for="machineName"> Strumento utilizzato </label>
		<select name='machineName'>
			<option value="0" selected> Seleziona lo strumento </option>
			<?php
				foreach($analytic as $a):
			?>
			<option value="<?php echo $a['codProduttore'] . '_' . $a['numSeriale'];?>"> <?php echo $a['nome'] . ': ' . $a['numSeriale'];?> </option>
			<?php 
				endforeach;
			?>
		</select>
		<input type="submit" id="BTNSubmit" value="Inserisci">
	</form>
	</body>
</html>