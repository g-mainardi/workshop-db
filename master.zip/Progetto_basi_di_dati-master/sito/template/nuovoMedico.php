<section>
	<h2>Registra un medico</h2>
	<form action="#" method="POST">
		<ul>
			<li>			
				<label for="CF"> Codice fiscale medico: </label>
				<input type="text" name="CF" placeholder="Codice fiscale" maxlength="16" required>
			</li>
			<li>			
				<label for="nome"> Nome medico: </label>
				<input type="text" name="nome" placeholder="Nome medico" maxlength="20" required>
			</li>
			<li>			
				<label for="cognome"> Cognome medico: </label>
				<input type="text" name="cognome" placeholder="Cognome medico" maxlength="20" required>
			</li>
			<li>			
				<label for="telefono"> Telefono medico: </label>
				<input type="tel" pattern="[0-9]{10}" maxlength="10" name="telefono" placeholder="Telefono medico">
			</li>
			<li>			
				<label for="mail"> Email: </label>
				<input type="email"  name="mail" placeholder="Email" maxlength="80">
			</li>
		</ul>
		<input type="submit" name="submit"  value="Inserisci medico">
	</form>
</section>


<section>
	<h2>Medici registrati</h2>
	<table>
		<thead>
			<tr>
				<th>CF</th><th>NOME</th><th>COGNOME</th><th>TELEFONO</th><th>MAIL</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["medici"] as $medico) :?>
			<tr>
				<td><?php echo $medico["CF"]?></td><td><?php echo $medico["nome"]?></td><td><?php echo $medico["cognome"]?></td><td><?php echo $medico["telefono"]?></td><td><?php echo $medico["mail"]?></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>