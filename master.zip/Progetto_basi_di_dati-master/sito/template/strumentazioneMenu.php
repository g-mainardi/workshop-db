<section>
<a href="inserimentoStrumento.php"><button type="button">STRUMENTI</button></a>    
<a href="inserimentoRevisione.php"><button type="button">REVISIONE</Button></a>
<a href="inserimentoProduttori.php"><button type="button">PRODUTTORI</Button></a>	

</section>
