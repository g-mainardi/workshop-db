<section>
<a href="inserimentoMateriali.php"><button type="button">MATERIALI</button></a>  
<a href="inserimentoLotti.php"><button type="button">LOTTI</Button></a>
<a href="inserimentoFornitori.php"><button type="button">FORNITORI</Button></a>	

</section>