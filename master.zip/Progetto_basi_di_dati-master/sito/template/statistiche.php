<section>
	<h2>Statistiche</h2>
	<form name="dates" action="<?php echo $_SERVER["PHP_SELF"];?>" method="GET">
		<ul>
			<li>
				<label for="startDate"> Data inizio: </label>
				<input type="date" name="startDate" id="startDate"/>
			</li>
			<li>
				<label for="endDate"> Data fine: </label>
				<input type="date" name="endDate" id="endDate"/>
			</li>
		</ul>
		<input type="submit" name="BTNSubmit" value="Visualizza statistiche">
	</form>
	<?php
		if(isset($_GET) && sizeof($_GET) > 0){
			if(sizeof($mostFrequentExam) <= 0){
				echo "<p>Non è stato eseguito alcun esame in questo periodo</p>";
			} else {
				echo "<h3>Risultati</h3>";
				echo "<p>Esame più frequente: <strong>" . $mostFrequentExam[0]['nome'] . "</strong>, eseguito " . $mostFrequentExam[0]['NumeroEsami'] . " volte.</p>";
				echo "<p>Il luogo in cui sono stati eseguiti più esami è: <strong>" . $mostFrequentSpecimenCollectionPlace[0]['via'] . " " . $mostFrequentSpecimenCollectionPlace[0]['civico'] . ", " . $mostFrequentSpecimenCollectionPlace[0]['provincia'] . ", " . $mostFrequentSpecimenCollectionPlace[0]['CAP'] . "</strong>. Sono stati eseguiti " . $mostFrequentSpecimenCollectionPlace[0]['numero_prelievi'] . " prelievi</p>";
				echo "<p>Lo strumento più utilizzato è: <strong>" . $mostUsedAnalyzingTool[0]['nome_strumento'] . " (produttore: " . $mostUsedAnalyzingTool[0]['nome_produttore'] . ", numero seriale: " . $mostUsedAnalyzingTool[0]['numSer_str'] . ")</strong>.  E' stato usato " . $mostUsedAnalyzingTool[0]['NumEsami'] . " volte</p>";
				echo "<p>Il settore analitico più frequente è: <strong>" . $mostFrequentExamType[0]['nome'] . "</strong>. Sono stati eseguiti " . $mostFrequentExamType[0]['numero_esami'] . " esami</p>";
				echo "<p>Sono stati eseguiti un totale di <strong>" . $specimenCount[0]["NumPrelievi"] . "</strong> prelievi in questo periodo.</p>";
			}
		}
	?>
</section>
