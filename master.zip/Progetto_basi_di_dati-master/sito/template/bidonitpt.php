<section>
	<h2>Inserisci un nuovo bidone</h2>
	<form action="#" method="POST">
		<ul>
			<li>			
				<label for="peso"> peso bidone: </label>
				<input type="num" min="1" step="1" name="peso" placeholder="peso iniziale bidone" maxlength="16" required>
			</li>

		</ul>
		<input type="submit" name="AggiungiBidone"  value="Inserisci nuovo bidone">
	</form>
</section>

<section>
		<table>
			<thead>
				<tr>
					<th> Codice bidone </th>
					<th> Peso </th>
					<th> Azioni </th>
				</tr>
			</thead>
			<tbody>
			<?php
				foreach($SetParameters["bidoni_rifiuti_speciali"] as $bin):
			?>
			<form action="#" method="POST">
				<tr>
					<td> <input type="hidden" name="binCode" value=<?php echo $bin['codBidone']; ?>> <?php echo $bin['codBidone']; ?> </td>
					<td> <input type="numeric" name="value" value=<?php echo $bin['peso']; ?>> </td>
					<td> <input type="submit" name="BTNSubmitUpdate" value="Aggiorna peso"> <input type="submit" name="BTNSubmitClose" value="Chiudi bidone"> <input type="submit" name="BTNSubmitBoth" value="Aggiorna e chiudi bidone"> </td>
				</tr>
			</form>
			<?php
				endforeach;
			?>
			</tbody>
		</table>
</section>

<section>
	<h2>Bidoni chiusi</h2>
	<table>
		<thead>
			<tr>
				<th>DATA CHIUSURA</th><th>PESO</th><th>CODICE BIDONE</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["bidoni_rifiuti_speciali_chiusi"] as $closedBins) :?>
				<tr>
					<td><?php echo $closedBins["data_chiusura"]?></td><td><?php echo $closedBins["peso"]?></td><td><?php echo $closedBins["codBidone"]?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>