<section>
	<h2>Inserisci il prezzo di un esame</h2>
	<form action="#" method="POST">
		<ul>
			<li>
				<label for="listino">listini: </label>
				<select name='listino'>
					<option value="0" selected> Seleziona il listino </option>
					<?php
						foreach($SetParameters["listini"] as $listino):
					?>
					<option value="<?php echo $listino['codListino']?>"> <?php echo $listino['nome']?> </option>
					<?php 
						endforeach;
					?>
				</select>
			</li>


			<li>
				<label for="settoreEsame">Settore analitico ed Esame: </label>
				<select name='settoreEsame'>
					<option value="0" selected> seleziona il settore analitico e l'esame</option>
					<?php
						foreach($SetParameters["esami"] as $SettoreEsame):
					?>
					<option value="<?php echo $SettoreEsame['setID'] ."  -  ". $SettoreEsame['nome']; ?>"> <?php echo $SettoreEsame['codSet'] ."  -  ". $SettoreEsame['nome'];?> </option>
					<?php 
						endforeach;
					?>
				</select>
			</li>			
			<li>			
				<label for="valore"> valore esame: </label>
				<input type="number"  pattern="[0-9]+([\.,][0-9]+)?" step="0.01" name="valore" placeholder="valore" maxlength="4" required>
			</li>
		</ul>
		<input type="submit" name="insertPrice"  value="Inserisci prezzo esame">
	</form>
</section>


<section>
	<h2>prezzi esami</h2>
	<table>
		<thead>
			<tr>
				<th>LISTINO</th><th>SETTORE ANALITICO</th><th>NOME ESAME</th><th>VALORE</th><th colspan="2">AGGIORNA VALORE</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($SetParameters["prezzi_esami"] as $prezzi) :?>
				<tr>
					<td><?php echo $prezzi["nome_listino"]?></td><td><?php echo $prezzi["nome_settore"]?></td><td><?php echo $prezzi["nome_es"]?></td><td><?php echo $prezzi["valore"]?></td>
					<td>
						<form action="#" method="POST">
							<input type="num" name="aggiornaValore" placeholder="aggiorna valore"  min="1" step="1" maxlength="20" required>	
					</td>
					<td>
							<input type="hidden" name="IDlistino" value="<?php echo $prezzi["codListino"]?>" />
							<input type="hidden" name="IDsettore" value="<?php echo $prezzi["codSet_es"]?>" />
							<input type="hidden" name="nome_esame" value="<?php echo $prezzi["nome_es"]?>" />
							<input type="submit" name="VLupdate"  value="aggiorna">
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>