<?php
	require_once 'require.php';
	echo json_encode($db->getEsamiPazientiData($_POST["CF"],$_POST["data_inizio"],$_POST["data_fine"]));
	exit;
?>
