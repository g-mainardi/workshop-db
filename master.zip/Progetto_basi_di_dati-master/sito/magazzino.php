<?php
    $SetParameters["titolo"] = "Home";
    $SetParameters["file"] = "magazzinoMenu.php";
    require("template/base.php");
?>