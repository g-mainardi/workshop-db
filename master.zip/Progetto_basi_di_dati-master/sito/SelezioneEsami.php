<?php


    $SetParameters["titolo"] = "Menu esami";
    $SetParameters["file"] = "esameMenu.php";
    require("template/base.php");
?>
