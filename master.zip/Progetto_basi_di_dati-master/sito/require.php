<?php
session_start();
//Inclusion of db and functions
require_once("database.php");
$db = new DatabaseHelper("127.0.0.1", "root", "", "progetto_basi_di_dati", 3306);
//Costanti
define("UPLOAD_DIR", "./upload/");
?>
