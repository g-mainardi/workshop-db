<?php
    require_once 'require.php';

    $SetParameters["titolo"] = "Inserimento medico";
    $SetParameters["file"] = "nuovoMedico.php";
    $SetParameters["medici"] = $db->getMedici();
    
    if(isset($_POST["CF"]) && isset($_POST["nome"]) && isset($_POST["cognome"]) && isset($_POST["telefono"]) && isset($_POST["mail"])){
		$error = false;
		if(strlen($_POST['nome']) <= 0 || strlen($_POST['cognome']) <= 0){
			echo "Nome e cognome non possono essere vuoti<br>";
			$error = true;
		}
		if(!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)){
			echo "L'email non ha un giusto formato<br>";
			$error = true;
		}
		if(strlen($_POST['CF']) != 16){
			echo "Il codice fiscale è composto da esattamente 16 caratteri<br>";
			$error = true;
		}
		if(!is_numeric($_POST['telefono'])){
			echo "Numero di telefono non valido<br>";
			$error = true;
		}
		if($db->checkAll(($_POST['CF']))!=0)
		{
			echo "CF gia presente nel database<br>";
			$error = true;
		}
		if(!$error){
			$db->insertMedic($_POST["CF"], $_POST["nome"], $_POST["cognome"], $_POST["telefono"], $_POST["mail"]);
		}
        
    }

 require("template/base.php");
?>