<?php
	require_once 'require.php';
	echo json_encode($db->getEsamiEffettuatiByCFCliente($_POST["CF_cliente"]));
	exit;
?>
