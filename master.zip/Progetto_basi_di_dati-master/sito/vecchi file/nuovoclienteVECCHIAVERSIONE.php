<?php
	require_once 'utilities/functions.php';
	$connection = connect();
	
	$query = $connection->prepare('SELECT CF, nome, cognome FROM medici');
	$query->execute();
	$result = $query->get_result();
	$doctors = $result->fetch_all(MYSQLI_ASSOC);
	
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if($_POST['doctors'] == "0")
			echo "Devi selezionare il medico curante del paziente";
		elseif(!is_numeric($_POST['customerphone'])){
			echo "Numero di telefono con formato sbagliato";
		}
		else{
			$query = $connection->prepare('SELECT * FROM clienti WHERE CF=?');
			$query->bind_param("s", $_POST["customerCF"]);
			$query->execute();
			$result = $query->get_result();
			if($result->num_rows > 0){
				echo "Cliente già presente";
			}
			else{
				$query = $connection->prepare('INSERT INTO clienti (CF, nome, cognome, telefono, data_nascita, luogo_nascita, indirizzo_residenza, mail, Medico_CF) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
				$query->bind_param("sssssssss", $_POST["customerCF"], $_POST["customername"], $_POST["customersurname"], $_POST["customerphone"], $_POST["customerbirthdate"], $_POST["customerbirthplace"], $_POST["customeraddress"], $_POST["customeremail"], $_POST["doctors"]);
				$query->execute();
				if(!$query){
					echo "Qualcosa e' andato storto nell'inserimento";
				}
				else{
					echo "Cliente inserito con successo";
					echo "<meta http-equiv='refresh' content='0'>";
				}
			}
		}
	}
?>


	<section>
	<form name="newcustomerform" action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST">
		<label for="customerCF"> Codice fiscale cliente: </label>
		<input type="text" name="customerCF" placeholder="Codice fiscale" maxlength="16" required>
		<label for="customername"> Nome cliente: </label>
		<input type="text" name="customername" placeholder="Nome paziente" maxlength="20" required>
		<label for="customersurname"> Cognome cliente: </label>
		<input type="text" name="customersurname" placeholder="Cognome paziente" maxlength="20" required>
		<label for="customerphone"> Telefono cliente: </label>
		<input type="text" name="customerphone" placeholder="Telefono paziente" maxlength="10">
		<label for="customerbirthdate"> Data di nascita: </label>
		<input type="date" name="customerbirthdate">
		<label for="customerbirthplace"> Città di nascita: </label>
		<input type="text" name="customerbirthplace" placeholder="Città di nascita" maxlength="20" required>
		<label for="customeraddress"> Indirizzo di residenza: </label>
		<input type="text" name="customeraddress" placeholder="Indirizzo" maxlength="80" required>
		<label for="customeremail"> Email: </label>
		<input type="text" name="customeremail" placeholder="Email" maxlength="80" required>

		<label for="doctors">Medico: </label>
		<select name='doctors'>
			<option value="0" selected> Seleziona il medico curante </option>
			<?php
				foreach($doctors as $doc):
			?>
			<option value="<?php echo $doc['CF']?>"> <?php echo $doc['cognome'] . " " . $doc['nome'];?> </option>
			<?php 
				endforeach;
			?>
		</select>
		
		<input type="submit" name="BTNSubmit" name="BTNSubmit" value="Inserisci cliente">
	</form>

</section>

<section>
	<h2>clienti registrati</h2>
	<table>
		<tr>
			<th>CF</th><th>NOME</th><th>COGNOME</th><th>TELEFONO</th><th>DATA DI NASCITA</th><th>LUOGO DI NASCITA</th><th>INDIRIZZO RESIDAENZA</th><th>MAIL</th><th>CF MEDICO</th>
		</tr>
		<?php foreach($SetParameters["clienti"] as $cliente) :?>
			<tr>
				<td><?php echo $cliente["CF"]?></td><td><?php echo $cliente["nome"]?></td><td><?php echo $cliente["cognome"]?></td><td><?php echo $cliente["telefono"]?></td>
				<td><?php echo $cliente["data_nascita"]?></td><td><?php echo $cliente["luogo_nascita"]?></td><td><?php echo $cliente["indirizzo_residenza"]?></td>
				<td><?php echo $cliente["mail"]?></td><td><?php echo $cliente["Medico_CF"]?></td>
			</tr>
		
		<?php endforeach; ?>

	</table>
</section>