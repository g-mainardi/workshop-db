<?php
	require_once '../utilities/functions.php';
	require_once '../require.php';
	$connection = connect();
	$exams = "";
	if($_SERVER['REQUEST_METHOD'] == 'GET' && $_GET){
		if(strlen($_GET['customerCF']) != 16)
			echo "Codice fiscale sbagliato";
		elseif(!$_GET['customerspecimendate']){
			echo "Inserire la data del prelievo";
		}
		else{
			$query = $connection->prepare('SELECT ef.nome, ef.valore_rilevato, settori_analitici.nome AS nomeSettore, ef.codSet AS codiceSettore FROM esami_effettuati ef JOIN campioni c ON c.codCampione = ef.codCampione JOIN settori_analitici ON ef.codSet = settori_analitici.codSet WHERE c.data = ? AND c.CF_cliente = ? ORDER BY codiceSettore');
			$query->bind_param("ss", $_GET['customerspecimendate'], $_GET["customerCF"]);
			$query->execute();
			$result = $query->get_result();
			$query->store_result();
			$exams = $result->fetch_all(MYSQLI_ASSOC);
		}
	}
?>

<!DOCTYPE html>
<html lang='it'>
	<head>
		<link rel="shortcut icon" type="image/ico" href="img/favicon.ico">
		<title> Esami dato prelievo - Laboratorio Analisi </title>
	</head>
	<body>
	<form name="esami_prelievi_form" action="<?php echo $_SERVER["PHP_SELF"];?>" method="GET">
		<label for="customerCF"> Codice fiscale cliente: </label>
		<input type="text" name="customerCF" placeholder="Codice fiscale" maxlength="16" required>
		<label for="customerspecimendate"> Data prelievo: </label>
		<input type="date" name="customerspecimendate">
		<input type="submit" id="BTNSubmit" value="Cerca esami">
	</form>
	
	<?php
		if($_GET):
			if($query->num_rows > 0):
		?>
			Non sono stati trovati esami con quella combinazione
		<?php
			else:
				foreach($exams as $e):
				$query = $connection->prepare('SELECT valore, unita, tipo, nome_vincolo, sesso FROM parametri WHERE codSet_es =' . $e['codiceSettore'] . ' AND nome_es = "' . $e['nome'] . '" AND tipo="PARAMETRO_ORDINARIO" ORDER BY sesso');
				$query->execute();
				$result = $query->get_result();
				$query->store_result();
				$examParameters = $result->fetch_all(MYSQLI_ASSOC);
				
				if(!isset($lastExamType) || $lastExamType != $e['nomeSettore']):
					if(isset($lastExamType)){
						echo "</table>";
					}
		?>
			<table border="1">
			<caption> <?php echo $e['nomeSettore'] ?> </caption>
			<tr>
				<td> Nome esame </td>
				<td> Valore rilevato </td>
				<td> Parametri ideali </td>
			</tr>
		<?php
				endif;
				$minMax = "";
				$min = "No min";
				$max = "No max";
				
				if (sizeof($examParameters) > 0){
					foreach($examParameters as $eP){
						if(!isset($sesso) || $sesso != $eP['sesso']){
							if($min != "No min" || $max != "No max") {
								$minMax .= $min .' - '. $max . ' (' . $examParameters[0]['unita'] . ') (' . $sesso . ')';
							}
							$minMax .= '<br />';
							$min = "No min";
							$max = "No max";
							unset($sesso);
						}
						$sesso = $eP['sesso'];
						if(is_numeric($max) && intval($eP['valore']) > intval($max)){
							$min = $max;
							$max = $eP['valore'];
						} else {
							$max = $eP['valore'];
						}
					}
					if($min != "No min" || $max != "No max") {
						$minMax .= $min .' - '. $max . ' (' . $examParameters[0]['unita'] . ') (' . $sesso . ')';
					}
				}
				
				$query = $connection->prepare('SELECT valore, unita, tipo, nome_vincolo, sesso FROM parametri WHERE codSet_es = ' . $e['codiceSettore'] . ' AND nome_es = "' . $e['nome'] . '" AND nome_vincolo IS NOT NULL');
				$query->execute();
				$result = $query->get_result();
				$query->store_result();
				$examSpecialParameters = $result->fetch_all(MYSQLI_ASSOC);
		?>
			<tr>
				<td> <?php echo $e['nome']; ?> </td>
				<td> <?php echo $e['valore_rilevato']; if(intval($e['valore_rilevato']) > intval($max) || intval($e['valore_rilevato']) < intval($min)) {echo '*';} ?> </td>
				<td> <?php echo $minMax; 
				$p = '';
					foreach($examSpecialParameters as $specialParam){
						$p .= '<br />' . $specialParam['nome_vincolo'] . ": " . $specialParam['valore'] . " " . $specialParam['unita'] . ' (' . $specialParam['sesso'] . ')';
					}
				if(strlen($p) > 0){
					echo $p;
				}
				?> </td>
			</tr>
		<?php
				$lastExamType = $e['nomeSettore'];
				endforeach;
				echo "</table>";
			endif;
		endif;
	?>
	</body>
</html>