<?php

    require_once 'require.php';

    $SetParameters["titolo"] = "Rifiuti";
    $SetParameters["file"] = "bidonitpt.php";
    $SetParameters["bidoni_rifiuti_speciali"]= $db->getUnclosedBins();
    $SetParameters["bidoni_rifiuti_speciali_chiusi"]= $db->getClosedBins();

    if(isset($_POST['AggiungiBidone']) && isset($_POST['peso'])){
        $db->insertBin($_POST["peso"]);
    }

    if(isset($_POST['BTNSubmitUpdate']) || isset($_POST['BTNSubmitBoth'])){
        if(!is_numeric($_POST['value'])){
            echo "Devi inserire un valore numerico come peso";
        }

        else{
            $update = $db->updateBin($_POST['binCode'], $_POST['value']);
            if(!$update){
                echo "Peso bidone aggiornato";
            } else {
                echo "Errore aggiornamento peso";
            }
        }
    }
    if(isset($_POST['BTNSubmitClose']) || isset($_POST['BTNSubmitBoth'])){
        if(!is_numeric($_POST['value'])){
            echo "Devi inserire un valore numerico come peso";
        } else {
            $close = $db->closeBin($_POST['binCode']);
            if(!$close){
                echo "Bidone chiuso con successo";
            } else {
                echo "Errore chiusura bidone";
            }
        }
    }


    require("template/base.php");
?>