<?php



    $SetParameters["titolo"] = "Anagrafica";
    $SetParameters["file"] = "anagraficaMenu.php";
    require("template/base.php");



?>