<?php

    require_once 'require.php';

    $SetParameters["titolo"] = "Inserimento fornitore";
    $SetParameters["file"] = "nuovoFornitore.php";
    $SetParameters["fornitori"] = $db->getFornitori();
    
    if(isset($_POST["nome"]) && strlen($_POST['nome']) > 0){
			$checkFornitore = $db->getFornitoreByName(($_POST['nome']));
			if(sizeof($checkFornitore) == 0){
				$db->insertFornitore($_POST["nome"]);
				echo "Fornitore inserito";
			} else {
				echo "Esiste già un fornitore con questo nome";
			}    
    }


 require("template/base.php");
?>
