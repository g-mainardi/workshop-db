<?php
	require_once 'require.php';
    $SetParameters["titolo"] = "produttori";
    $SetParameters["file"] = "nuovoProduttore.php";
	$SetParameters["produttori"] = $db->getProduttori();

	if(isset($_POST["nome"]) && strlen($_POST['nome']) > 0){
		$checkProduttore = $db->getProduttoreByName(($_POST['nome']));
		if(sizeof($checkProduttore) == 0){
			$db->insertProduttore($_POST["nome"]);
			echo "Produttore inserito";
		} else {
			echo "Esiste già un Produttore con questo nome";
		}    
	}
	
    require("template/base.php");
?>