<?php
    require_once 'require.php'; 
    $SetParameters["titolo"] = "Menu strumentazione";
    $SetParameters["file"] = "strumentazioneMenu.php";
    require("template/base.php");
?>