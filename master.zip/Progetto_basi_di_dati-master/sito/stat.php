<?php
	require_once 'require.php';
    $SetParameters["titolo"] = "Home";
    $SetParameters["file"] = "statistiche.php";
	if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET) && sizeof($_GET) > 0){
		$mostFrequentExam = $db->getMostFrequentExam($_GET['startDate'], $_GET['endDate']);
		$mostFrequentSpecimenCollectionPlace = $db->getMostSpecimenCollectionPlace($_GET['startDate'], $_GET['endDate']);
		$mostUsedAnalyzingTool = $db->getMostUsedAnalyzingTool($_GET['startDate'], $_GET['endDate']);
		$mostFrequentExamType = $db->getMostFrequentExamType($_GET['startDate'], $_GET['endDate']);
		$specimenCount = $db->getSpecimenCollectionCount($_GET['startDate'], $_GET['endDate']);
	}
    require("template/base.php");
?>
