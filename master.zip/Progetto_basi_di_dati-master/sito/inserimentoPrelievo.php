<?php
    require_once 'require.php';

	$infermieri = $db->getInfermieri();
	$listini = $db->getListini();
	$luoghi = $db->getPuntiPrelievo();
	$camp;
	$prelievo;
	if(isset($_POST) && sizeof($_POST) > 0){
		if(isset($_POST['submitInsert'])){
			if(isset($_POST['customerCF']) && strlen($_POST['customerCF']) == 16 &&
			strlen($_POST['prelievoDate']) > 0 &&
			$_POST['infermiere'] != "0" &&
			$_POST['listino'] != "0" &&
			$_POST['place'] != "0") {
				$db->insertPrelievo($_POST['customerCF'], $_POST['prelievoDate'], $_POST['infermiere'], $_POST['listino'], $_POST['place']);
				echo "Prelievo inserito";
			} else {
				echo "Non hai inserito tutti i campi necessari";
			}
		}
	}
	if(isset($_POST) && sizeof($_POST) > 0 && isset($_POST['submitTable'])){
		$camp = $db->getCampioniFromPrelievo($_POST['customerCF'], $_POST['prelievoDate']);
	} else {
		unset($camp);
	}
	
	if(isset($_POST) && sizeof($_POST) > 0 && isset($_POST['submitTracciamento'])){
		$prelievo = $db->getPrelievo($_POST['customerCF'], $_POST['prelievoDate']);
		if(sizeof($prelievo) > 0){
			$prelievo = $prelievo[0];
		} else {
			unset($prelievo);
		}
	} else {
		unset($prelievo);
	}

?>

<h2> Inserimento prelievo </h2>

<section>
	<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST">
		<label for="customerCF"> Codice fiscale cliente: </label>
		<input type="text" name="customerCF" placeholder="Codice fiscale" maxlength="16" required>
		<label for="prelievoDate"> Data prelievo: </label>
		<input type="date" name="prelievoDate">

		<label for="infermiere">Infermiere che ha eseguito il prelievo: </label>
		<select name='infermiere'>
			<option value="0" selected> Seleziona l'infermiere </option>
			<?php
				foreach($infermieri as $inf):
			?>
			<option value="<?php echo $inf['CF'];?>"> <?php echo $inf['cognome'] . " " . $inf['nome'] . " - " . $inf['CF'];?> </option>
			<?php 
				endforeach;
			?>
		</select>
		<label for="listino">Listino applicato: </label>
		<select name='listino'>
			<option value="0" selected> Seleziona il listino</option>
			<?php
				foreach($listini as $lis):
			?>
			<option value="<?php echo $lis['codListino'];?>"> <?php echo $lis['nome'];?> </option>
			<?php 
				endforeach;
			?>
		</select>
		<label for="place">Luogo prelievo: </label>
		<select name='place'>
			<option value="0" selected> Seleziona il luogo</option>
			<?php
				foreach($luoghi as $l):
			?>
			<option value="<?php echo $l['codPP'];?>"> <?php echo $l['via'] . "  " . $l['civico'] . ",  " . $l['provincia'] . ", " . $l['CAP'];?> </option>
			<?php 
				endforeach;
			?>
		</select>
		
		<input type="submit" name="submitInsert"  value="Inserisci prelievo">
	</form>

</section>

<h2> Tracciamento prelievo </h2>
<section>
	<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST">
		<label for="customerCF"> Codice fiscale cliente: </label>
		<input type="text" name="customerCF" placeholder="Codice fiscale" maxlength="16" required>
		<label for="prelievoDate"> Data prelievo: </label>
		<input type="date" name="prelievoDate">
		
		<input type="submit" name="submitTracciamento"  value="Visualizza prelievo">
	</form>

<?php
	if(isset($prelievo) && isset($_POST['submitTracciamento'])):
?>
	<table border=1>
		<tr>
			<th> Codice fiscale cliente </th>
			<th> Data prelievo </th>
			<th> Codice fiscale infermiere </th>
			<th> Listino </th>
			<th> Indirizzo prelievo </th>
		</tr>
		<tr>
			<td> <?php echo $prelievo['CF_cliente'] ?> </td>
			<td> <?php echo $prelievo['data'] ?> </td>
			<td> <?php echo $prelievo['CF_infermiere'] ?> </td>
			<td> <?php echo $prelievo['nome'] ?> </td>
			<td> <?php echo $prelievo['via'] . "  " . $prelievo['civico'] . ",  " . $prelievo['provincia'] . ", " . $prelievo['CAP'];?> </td>
		</tr>
	</table>
<?php
	elseif(isset($_POST['submitTracciamento'])):
?>
	Non sono stati trovati prelievi con quella combinazione
<?php
	endif;
?>


</section>


<h2> Visualizzazione campioni prodotti da un prelievo </h2>
<section>
	<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST">
		<label for="customerCF"> Codice fiscale cliente: </label>
		<input type="text" name="customerCF" placeholder="Codice fiscale" maxlength="16" required>
		<label for="prelievoDate"> Data prelievo: </label>
		<input type="date" name="prelievoDate">
		
		<input type="submit" name="submitTable"  value="Visualizza campioni">
	</form>

<?php
	if(isset($camp)):
?>
	<table border=1>
		<tr>
			<th> Codice campione </th>
			<th> Tipo campione </th>
		</tr>
		<?php
			foreach($camp as $c):
		?>
		<tr>
			<td> <?php echo $c['codCampione'] ?> </td>
			<td> <?php echo $c['nome'] ?> </td>
		</tr>
		<?php
			endforeach;
		?>

	</table>
<?php
	endif;
?>

</section>
