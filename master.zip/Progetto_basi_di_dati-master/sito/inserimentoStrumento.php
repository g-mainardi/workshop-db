<?php

    require_once 'require.php'; 

    $SetParameters["titolo"] = "Strumenti";
    $SetParameters["file"] = "strumenti.php";
    $SetParameters["produttori"] = $db->getProduttori();
    $SetParameters["settori_analitici"] = $db->getSetAn();
    $SetParameters["strumenti"] = $db->getStrumenti();

    if(isset($_POST["produttore"])
     && ($_POST["produttore"]!=0)
     && isset($_POST["seriale"]) 
     && isset($_POST["settore"]) 
     && ($_POST["settore"]!=0)
     && isset($_POST["nome"]) 
    ){
        $db->insertStrumenti(
        $_POST["produttore"], 
        $_POST["seriale"], 
        $_POST["settore"],
        $_POST["nome"]
        );
    }

    require("template/base.php");
?>