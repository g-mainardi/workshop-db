<?php

    require_once 'require.php';

    $SetParameters["titolo"] = "Inserimento cliente";
    $SetParameters["file"] = "nuovocliente.php";
    $SetParameters["clienti"] = $db->getClienti();
    $SetParameters["medici"] = $db->getMedici();


    if(isset($_POST["clienteCF"]) && isset($_POST["clienteNome"]) && isset($_POST["clienteCognome"]) && isset($_POST["clienteTelefono"]) && isset($_POST["clienteDataNascita"]) && isset($_POST["clienteLuogoNascita"]) && isset($_POST["clienteIndirizzo"]) && isset($_POST["clienteMail"]) && isset($_POST["dottore"]) && ($_POST["dottore"]!=0)){
			$error = false;
			if(strlen($_POST['clienteNome']) <= 0 || strlen($_POST['clienteCognome']) <= 0){
				echo "Nome e cognome non possono essere vuoti<br>";
				$error = true;
			}
			if(!filter_var($_POST['clienteMail'], FILTER_VALIDATE_EMAIL)){
				echo "L'email non ha un giusto formato<br>";
				$error = true;
			}
			if(strlen($_POST['clienteCF']) != 16){
				echo "Il codice fiscale è composto da esattamente 16 caratteri<br>";
				$error = true;
			}
			if(!is_numeric($_POST['clienteTelefono'])){
				echo "Numero di telefono non valido<br>";
				$error = true;
			}
			if($db->checkAll(($_POST['clienteCF']))!=0)
			{
				echo "CF gia presente nel database<br>";
				$error = true;
			}
			if(!$error){
				$db->insertCliente($_POST["clienteCF"], $_POST["clienteNome"], $_POST["clienteCognome"], $_POST["clienteTelefono"], $_POST["clienteDataNascita"], $_POST["clienteLuogoNascita"], $_POST["clienteIndirizzo"], $_POST["clienteMail"], $_POST["dottore"]);
			}
        }

    require("template/base.php");

?>