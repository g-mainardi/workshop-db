<?php
	require_once 'require.php';
	echo json_encode($db->getTecnicoByExam($_POST["codCampione"],$_POST["codSet"],$_POST["nome"]));
	exit;
?>
