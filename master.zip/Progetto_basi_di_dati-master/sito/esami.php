<?php
	require_once 'require.php';
    $SetParameters["titolo"] = "Esami";
    $SetParameters["file"] = "esamitpt.php";
	$templateParams["setAn"] = $db->getSetAn();
	$templateParams["exams"] = $db->getExams();
	$templateParams["cpn"] = $db->getCpn();
	$templateParams["tecn"] = $db->getTecnici();
	$templateParams["str"] = $db->getStr();
	$templateParams["cli"] = $db->getClienti();
	if(isset($_POST["nome_setAn"])) {
		if (strlen($_POST["nome_setAn"]) < 4) {
			echo "Errore: inserire il nome di un settore analitico valido!";
		} else {
			$db->insertSetAn($_POST["nome_setAn"]);
		}
	} else if(isset($_POST["settore_analitico"]) && isset($_POST["nome_esame"])) {
		if (strlen($_POST["nome_esame"])  < 4) {			
			echo "Errore: inserire il nome di un esame valido!";
		} else {
			$db->insertExam($_POST["settore_analitico"],$_POST["nome_esame"]);
		}
	} else if(isset($_POST["nome_esame_ril"]) && isset($_POST["nome_campione_ril"]) && isset($_POST["CF_tecnico_ril"]) && isset($_POST["val_ril"]) && isset($_POST["data_ril"]) && isset($_POST["str_ril"])) {
		$err = 0;
		if (!is_numeric($_POST["nome_campione_ril"])) {
			echo "Errore: campione non valido!<br>";
			$err = 1;
		}
		if (strlen($_POST["CF_tecnico_ril"]) != 16) {
			echo "Errore: tecnico non trovato!<br>";
			$err = 1;
		}
		if (!is_numeric($_POST["val_ril"])) {
			echo "Errore: valore dell'esame non valido!<br>";
			$err = 1;
		}
		if ($db->checkRil($_POST["nome_esame_ril"], $_POST["nome_campione_ril"])) {
			echo "Errore: è gia stato effettuato questo esame per questo campione!<br>";
			$err = 1 ;
		}
		if (!$err) {
			$db->insertRil($_POST["nome_esame_ril"], $_POST["nome_campione_ril"], $_POST["CF_tecnico_ril"], $_POST["val_ril"], $_POST["data_ril"], $_POST["str_ril"]);
		}
	} else if(isset($_POST["val_param"]) && isset($_POST["unit_param"]) && isset($_POST["nome_esame_param"]) && isset($_POST["tipo_param"])) {
		$err = 0;
		if (!is_numeric($_POST["val_param"])) {
			echo "Errore: valore del parametro non valido!<br>";
			$err = 1;
		}		
		if (strlen($_POST["unit_param"]) == 0) {
			echo "Errore: unità di misura non valida!<br>";
			$err = 1;
		}
		if ($_POST["tipo_param"] == "1") {
			if (!is_numeric($_POST["eMin_param"])) {
				echo "Errore: età minima non valida!<br>";
				$err = 1;
			}
			if (!is_numeric($_POST["eMax_param"])) {
				echo "Errore: età massima non valida!<br>";
				$err = 1;
			}
			if ($_POST["sex_param"] != "M" && $_POST["sex_param"] != "F" && $_POST["sex_param"] != "A") {
				echo "Errore: sesso non valido!<br>";
				$err = 1;
			}
		} elseif ($_POST["tipo_param"] == "2") {
			if (strlen($_POST["nome_param"]) < 4) {
				echo "Errore: nome del vincolo non valido!<br>";
				$err = 1;
			}
		}
		if (!$err) {
			$db->insertParam($_POST["val_param"],$_POST["unit_param"],$_POST["nome_esame_param"],$_POST["tipo_param"],$_POST["eMin_param"],$_POST["eMax_param"],$_POST["sex_param"],$_POST["nome_param"]);
		}
	}
    require("template/base.php");
?>
