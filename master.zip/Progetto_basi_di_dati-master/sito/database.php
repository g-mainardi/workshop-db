<?php
class DatabaseHelper {
	private $db;
	
	public function __construct($servername, $username, $password, $dbname, $port) {
		$this->db = new mysqli($servername, $username, $password, $dbname, $port);
		if($this->db->connect_error) {
			die("Connection failed!");
		}
	}	
	
	public function getSetAn() {
		$statement = $this->db->prepare("SELECT * FROM settori_analitici");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function getExams() {
		$statement = $this->db->prepare("SELECT e.nome AS nome, s.nome AS codSet, s.codSet AS setID
										 FROM esami e JOIN settori_analitici s ON s.codSet = e.codSet");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getCpn() {
		$statement = $this->db->prepare("SELECT * FROM campioni");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function insertTecnico($CF, $nome, $cognome, $telefono, $mail){
		$statement = $this->db->prepare('INSERT INTO tecnici_di_laboratorio (CF, nome, cognome, telefono, mail) VALUES (?, ?, ?, ?, ?)');
		$statement->bind_param('sssss', $CF, $nome, $cognome, $telefono, $mail);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function getTecnici() {
		$statement = $this->db->prepare("SELECT * FROM tecnici_di_laboratorio");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getTecnicoByCF($CF) {
		$statement = $this->db->prepare("SELECT * FROM tecnici_di_laboratorio WHERE CF = ?");
		$statement->bind_param("s", $CF);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC)[0];
	}

	public function getTecnicoByExam($codCampione,$codSet,$nome) {
		$statement = $this->db->prepare("SELECT t.CF, t.nome, t.cognome  
										 FROM esami_effettuati ef
										 JOIN tecnici_di_laboratorio t ON ef.CF_tecnico = t.CF
										 WHERE ef.codCampione= ?
										 AND ef.codSet= ?
										 AND ef.nome = ?");
		$statement->bind_param("iis", $codCampione, $codSet, $nome);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC)[0];
	}

	public function getStr() {
		$statement = $this->db->prepare("SELECT s.*, p.nome as nomeProd 
										 FROM strumenti s 
										 JOIN produttori p on p.codProduttore = s.codProduttore");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function insertMedic($CF, $nome, $cognome, $telefono, $mail){
		$statement = $this->db->prepare('INSERT INTO medici (CF, nome, cognome, telefono, mail) VALUES (?, ?, ?, ?, ?)');
		$statement->bind_param('sssss', $CF, $nome, $cognome, $telefono, $mail);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	
	}

	public function getMedici(){
		$statement = $this->db->prepare("SELECT * FROM medici");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function getUnclosedBins(){
		$statement = $this->db->prepare("SELECT codBidone, peso FROM bidoni_rifiuti_speciali WHERE data_chiusura IS NULL");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function insertBin($peso){
		$statement = $this->db->prepare("INSERT INTO bidoni_rifiuti_speciali (data_chiusura, peso) 
										 VALUES (NULL, ?) ");
		$statement->bind_param("s", $peso);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}
	
	public function updateBin($binCode, $weight){
		$statement = $this->db->prepare("UPDATE bidoni_rifiuti_speciali 
										 SET peso=? WHERE codBidone=?");
		$statement->bind_param("ss", $weight, $binCode);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
		
		return $result = $statement->get_result();
	}
	
	public function closeBin($binCode){
		$statement = $this->db->prepare("UPDATE bidoni_rifiuti_speciali 
										 SET data_chiusura=NOW() WHERE codBidone=?");
		$statement->bind_param("i", $binCode);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";

		return $result = $statement->get_result();
	}

	public function getClosedBins(){
		$statement = $this->db->prepare("SELECT * FROM bidoni_rifiuti_speciali WHERE data_chiusura IS NOT NULL");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function insertInfermiere($CF, $nome, $cognome, $telefono, $mail){
		$statement = $this->db->prepare('INSERT INTO infermieri (CF, nome, cognome, telefono, mail) VALUES (?, ?, ?, ?, ?)');
		$statement->bind_param('sssss', $CF, $nome, $cognome, $telefono, $mail);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function getInfermieri(){
		$statement = $this->db->prepare("SELECT * FROM infermieri");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function insertCliente($CF, $nome, $cognome, $telefono, $dataNascita, $luogoNasctia, $residenza, $mail, $medico){
		$statement = $this->db->prepare('INSERT INTO clienti (CF, nome, cognome, telefono, data_nascita, luogo_nascita, indirizzo_residenza, mail, Medico_CF) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
		$statement->bind_param('sssssssss', $CF, $nome, $cognome, $telefono, $dataNascita, $luogoNasctia, $residenza, $mail, $medico);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function getClienti(){
		$statement = $this->db->prepare("SELECT * FROM clienti");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);

	}
	
	public function getListini(){
		$statement = $this->db->prepare("SELECT * FROM listini");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);

	}
	
	public function getPuntiPrelievo(){
		$statement = $this->db->prepare("SELECT * FROM punti_prelievo");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function insertPrelievo($CF_cliente, $data, $CF_infermiere, $codListino, $codPP){
		$statement = $this->db->prepare('INSERT INTO prelievi (CF_cliente, data, CF_infermiere, codListino, codPP) VALUES (?, ?, ?, ?, ?)');
		$statement->bind_param('sssss', $CF_cliente, $data, $CF_infermiere, $codListino, $codPP);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function insertMateriale($nome, $reagente, $materialeSanitario, $quantita, $soglia){
		$statement = $this->db->prepare('INSERT INTO tipi_di_materiale (nome, reagente, materiale_sanitario, quantita_residua, quantita_di_soglia) VALUES (?, ?, ?, ?, ?)');
		$statement->bind_param('sssii', $nome, $reagente, $materialeSanitario, $quantita, $soglia);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function getMateriali(){
		$statement = $this->db->prepare("SELECT * FROM tipi_di_materiale");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getMaterialiEsauriti(){
		$statement = $this->db->prepare("SELECT * FROM tipi_di_materiale 
										 WHERE quantita_residua	<= quantita_di_soglia");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}




	public function aggiornaQuantitaMateriale($aggiornaQuantita , $IDmateriale){
		$statement = $this->db->prepare("UPDATE tipi_di_materiale 
										 SET quantita_residua = ? WHERE codMateriale = ?");
		$statement->bind_param("ii", $aggiornaQuantita, $IDmateriale);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}


	public function getSetAnName($id) {		
		$statement = $this->db->prepare("SELECT nome FROM settori_analitici WHERE codSet = ?");
		$statement->bind_param("i", $id);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC)[0]["nome"];
	}

	public function getEsamiEffettuatiByCFCliente($cf) {		
		$statement = $this->db->prepare("SELECT * 
										 FROM `esami_effettuati` ef 
										 JOIN campioni c on c.codCampione = ef.codCampione 
										 WHERE c.CF_cliente = ?");
		$statement->bind_param("s", $cf);
		$statement->execute();
		$result = $statement->get_result();

		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getEsamiPazientiData($CF,$data_inizio,$data_fine) {		
		$statement = $this->db->prepare("SELECT ef.nome, ef.valore_rilevato, ef.data
										 FROM esami_effettuati ef 
										 JOIN campioni c ON c.codCampione = ef.codCampione 
										 WHERE c.CF_cliente = ? AND ef.data BETWEEN ? AND ?");
		$statement->bind_param("sss", $CF, $data_inizio, $data_fine);
		$statement->execute();
		$result = $statement->get_result();

		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getPazienteFullName($CF) {		
		$statement = $this->db->prepare("SELECT nome, cognome FROM clienti WHERE CF = ?");
		$statement->bind_param("s", $CF);
		$statement->execute();
		$result = $statement->get_result();
		$data = $result->fetch_array(MYSQLI_ASSOC); 

		return $data["nome"] . " " . $data["cognome"];
	}

	public function getCampionebyId($codCampione) {				
		$statement = $this->db->prepare("SELECT * FROM campioni WHERE codCampione = ?");
		$statement->bind_param("i", $codCampione);
		$statement->execute();
		$result = $statement->get_result();

		return $result->fetch_array(MYSQLI_ASSOC);
	}

	public function getStrumentoByCodes($codProd,$numSer) {
		$vals = $this->getStr();
		foreach ($vals as $str) {
			if ($str["codProduttore"] == $codProd and $str["numSeriale"] == $numSer)
			return $str;
		}
	}

	public function insertSetAn($nome) {
		$statement = $this->db->prepare('INSERT INTO settori_analitici (nome, codSet) VALUES (?, NULL)');
		$statement->bind_param('s', $nome);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	
	}

	public function getCampioniFromPrelievo($CF, $data){
		$statement = $this->db->prepare("SELECT c.codCampione, c.codTipo, c.CF_cliente, c.data, tc.nome 
										 FROM campioni c 
										 JOIN tipi_di_campione tc ON c.codTipo = tc.codTipo 
										 WHERE CF_cliente=? AND data=?");
		$statement->bind_param('ss', $CF, $data);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function getInfermiereFromPrelievo($CF, $data){
		$statement = $this->db->prepare("SELECT i.* 
										FROM infermieri i
										JOIN prelievi p ON p.CF_infermiere = i.CF
										WHERE CF_cliente=? AND data=?");
		$statement->bind_param('ss', $CF, $data);
		$statement->execute();
		$result = $statement->get_result();	
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function insertExam($setAn, $nome) {
		$statement = $this->db->prepare('INSERT INTO esami (codSet, nome) VALUES (?, ?)');
		$statement->bind_param('is', $setAn, $nome);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";	
	}

	public function insertRil($esame, $codCampione, $CF_tecnico, $val, $data, $strumento) {
		list($nome,$codSet) = explode("-",$esame);
		list($codProd_str,$numSer_str) = explode("-",$strumento);
		$codSet = intval($codSet);
		$codCampione = intval($codCampione);
		$val = floatval($val);
		$numSer_str = intval($numSer_str);
		$codProd_str = intval($codProd_str);
		$statement = $this->db->prepare("INSERT INTO esami_effettuati (codSet, nome, codCampione, valore_rilevato, data, CF_tecnico, codProd_str, numSer_str) 
										 VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
		$statement->bind_param('isidssis', $codSet, $nome, $codCampione, $val, $data, $CF_tecnico, $codProd_str, $numSer_str);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";	
	}

	public function checkRil($esame, $codCampione) {
		list($nome,$codSet) = explode("-",$esame);
		$codSet = intval($codSet);
		$codCampione = intval($codCampione);
		$statement = $this->db->prepare("SELECT * FROM esami_effettuati 
										 WHERE codset = ? AND nome = ? AND codCampione = ?");
		$statement->bind_param('isi', $codSet, $nome, $codCampione);
		$statement->execute();
		$result = $statement->get_result();
		$res = $result->fetch_all(MYSQLI_ASSOC);
		if (sizeof($res) > 0) {
			return true;
		} else {
			return false;
		}
	}

	public function insertParam($valore, $unita, $esame_setAn, $tipo, $eta_min, $eta_max, $sesso, $nome_vincolo) {
		list($nome_es,$codSet) = explode("-",$esame_setAn);
		$codSet = intval($codSet);
		if ($eta_max != "") {
			$eta_max = intval($eta_max);
			$eta_min = intval($eta_min);
		}
		$valore = floatval($valore);
		if ($tipo === "0") {
			$statement = $this->db->prepare("INSERT INTO parametri (tipo, codParametro, valore, unita, eta_min, eta_max, nome_vincolo, sesso, codSet_es, nome_es) 
			VALUES ('', NULL, ?, ?, NULL, NULL, NULL, NULL, ? , ?)");
			$statement->bind_param("dsis", $valore, $unita, $codSet, $nome_es);
		} elseif ($tipo === "1") {
			$statement = $this->db->prepare("INSERT INTO parametri (tipo, codParametro, valore, unita, eta_min, eta_max, nome_vincolo, sesso, codSet_es, nome_es) 
			VALUES ('PARAMETRO_ORDINARIO', NULL, ?, ?, ?, ?, NULL, ?, ? , ?)");
			$statement->bind_param("dsiisis", $valore, $unita, $eta_min, $eta_max, $sesso, $codSet, $nome_es);
		} else {			
			$statement = $this->db->prepare("INSERT INTO parametri (tipo, codParametro, valore, unita, eta_min, eta_max, nome_vincolo, sesso, codSet_es, nome_es) 
			VALUES ('PARAMETRO_SPECIALE', NULL, ?, ?, NULL, NULL, ?, NULL, ? , ?)");
			$statement->bind_param("dssis", $valore, $unita,$nome_vincolo, $codSet, $nome_es);
		}
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";	
	}

	public function insertFornitore($nome){
		$statement = $this->db->prepare('INSERT INTO fornitori (nome) VALUES (?)');
		$statement->bind_param('s', $nome);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function getFornitori(){
		$statement = $this->db->prepare("SELECT * FROM fornitori");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);

	}

	
	public function getMostFrequentExam($dataInizio, $dataFine){
		$statement = $this->db->prepare("SELECT nome, COUNT(*) AS 'NumeroEsami' 
										FROM esami_effettuati 
										WHERE data BETWEEN ? AND ?
										GROUP BY nome
										ORDER BY COUNT(*) DESC
										LIMIT 1");
		$statement->bind_param('ss', $dataInizio, $dataFine);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function getMostSpecimenCollectionPlace($dataInizio, $dataFine){
		$statement = $this->db->prepare("SELECT pp.via, pp.CAP, pp.provincia, pp.civico, COUNT(*) AS numero_prelievi
										FROM punti_prelievo pp, prelievi pr
										WHERE pp.codPP = pr.codPP 
										AND pr.data BETWEEN ? AND ?
										GROUP BY pp.via, pp.CAP, pp.provincia, pp.civico
										ORDER BY numero_prelievi DESC
										LIMIT 1");
		$statement->bind_param('ss', $dataInizio, $dataFine);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

		public function getMostUsedAnalyzingTool($dataInizio, $dataFine){
		$statement = $this->db->prepare("SELECT strumenti.nome AS nome_strumento, produttori.nome AS nome_produttore, numSer_str, COUNT(*) AS NumEsami
										FROM esami_effettuati 
										JOIN produttori ON esami_effettuati.codProd_str = produttori.codProduttore
										JOIN strumenti ON codProd_str = strumenti.codProduttore AND numSer_str = numSeriale
										WHERE data BETWEEN ? AND ?
										GROUP BY codProd_str, numSer_str 
										ORDER BY COUNT(*) DESC
										LIMIT 1");
		$statement->bind_param('ss', $dataInizio, $dataFine);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function getMostFrequentExamType($dataInizio, $dataFine){
		$statement = $this->db->prepare("SELECT settori_analitici.nome, COUNT(*) AS numero_esami
										FROM esami_effettuati ef
										JOIN settori_analitici ON ef.codSet = settori_analitici.codSet
										WHERE ef.data BETWEEN ? AND ?
										GROUP BY ef.codSet
										ORDER BY numero_esami DESC
										LIMIT 1");
		$statement->bind_param('ss', $dataInizio, $dataFine);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getSpecimenCollectionCount($dataInizio, $dataFine){
		$statement = $this->db->prepare("SELECT COUNT(*) AS NumPrelievi 
										FROM prelievi
										WHERE data BETWEEN ? AND ?");
		$statement->bind_param('ss', $dataInizio, $dataFine);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function insertLotto($dataAcquisto, $IDMateriale, $metodica, $quantita, $dataScadenza, $IDFornitore){
		$statement = $this->db->prepare('INSERT INTO lotti (data_acquisto, codMateriale, metodica, quantita_acquistata, data_scadenza, codFornitore) VALUES (?, ?, ?, ?, ?, ?)');
		$statement->bind_param('sisisi', $dataAcquisto, $IDMateriale, $metodica, $quantita, $dataScadenza, $IDFornitore);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function getLotti() {
		$statement = $this->db->prepare("SELECT l.*, tipi_di_materiale.nome AS nome_materiale, fornitori.nome AS nome_fornitore FROM lotti l JOIN tipi_di_materiale ON l.codMateriale = tipi_di_materiale.codMateriale JOIN fornitori ON l.codFornitore = fornitori.codFornitore");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}	

	public function getFornitoreByName($nome){
		$statement = $this->db->prepare("SELECT * FROM fornitori WHERE nome = ?");
		$statement->bind_param('s', $nome);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function getStrumenti() {
		$statement = $this->db->prepare("SELECT l.*, produttori.nome AS nome_produttore, settori_analitici.nome AS nome_settore FROM strumenti l JOIN produttori ON l.codProduttore =  produttori.codProduttore JOIN settori_analitici ON l.codSet = settori_analitici.codSet  ");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function insertStrumenti($IDproduttore, $numero, $IDsettore, $nome){
		$statement = $this->db->prepare('INSERT INTO strumenti (codProduttore, numSeriale, codSet, nome) VALUES (?, ?, ?, ?)');
		$statement->bind_param('isis', $IDproduttore, $numero, $IDsettore, $nome);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}
	
	public function getLottoById($id) {
		$statement = $this->db->prepare("SELECT * FROM lotti WHERE codLotto = ?");
		$statement->bind_param('i', $id);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}
	
	public function getListinoByName($name){
		$statement = $this->db->prepare('SELECT * FROM listini WHERE nome = ?');
		$statement->bind_param('s', $name);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);

	}
	
	public function insertListino($name){
		$statement = $this->db->prepare('INSERT INTO listini (nome) VALUES (?)');
		$statement->bind_param('s', $name);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";

	}

	public function insertRevisioneMensile($codiceProduttore, $numeroSeriale, $data, $rapporto, $esito){
		$statement = $this->db->prepare('INSERT INTO controlli_mensili (codProd_str, numSer_str, data, rapporto, esito) VALUES (?, ?, ?, ?, ?)');
		$statement->bind_param('issss', $codiceProduttore, $numeroSeriale, $data, $rapporto, $esito);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function getMensili() {
		$statement = $this->db->prepare("SELECT l.*, produttori.nome AS nome_produttore FROM controlli_mensili l JOIN produttori ON l.codProd_str = produttori.codProduttore");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getMensiliNonPassate() {
		$statement = $this->db->prepare("SELECT l.*, produttori.nome AS nome_produttore FROM controlli_mensili l JOIN produttori ON l.codProd_str = produttori.codProduttore WHERE esito = 0");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}


	public function getAnnuali() {
		$statement = $this->db->prepare("SELECT l.*, produttori.nome AS nome_produttore FROM revisioni_annuali l JOIN produttori ON l.codProd_str = produttori.codProduttore");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getAnnualiNonPassate() {
		$statement = $this->db->prepare("SELECT l.*, produttori.nome AS nome_produttore FROM revisioni_annuali l JOIN produttori ON l.codProd_str = produttori.codProduttore WHERE esito = 0");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function insertRevisioneAnnuale($codiceProduttore, $numeroSeriale, $data, $esito, $rapporto){
		$statement = $this->db->prepare('INSERT INTO revisioni_annuali (codProd_str, numSer_str, data, esito, rapporto) VALUES (?, ?, ?, ?, ?)');
		$statement->bind_param('issss', $codiceProduttore, $numeroSeriale, $data, $esito, $rapporto);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}
	
	public function getEsamiFromPrelievo($date, $CF) {
		$statement = $this->db->prepare('SELECT ef.nome, ef.valore_rilevato, settori_analitici.nome AS nomeSettore, ef.codSet AS codiceSettore FROM esami_effettuati ef JOIN campioni c ON c.codCampione = ef.codCampione JOIN settori_analitici ON ef.codSet = settori_analitici.codSet WHERE c.data = ? AND c.CF_cliente = ? ORDER BY codiceSettore');
		$statement->bind_param("ss", $date, $CF);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function getParametroOrdinario($codSettore, $nomeEsame){
		$statement = $this->db->prepare('SELECT valore, unita, tipo, nome_vincolo, sesso FROM parametri WHERE codSet_es = ? AND nome_es = ? AND tipo="PARAMETRO_ORDINARIO" ORDER BY sesso');
		$statement->bind_param("is", $codSettore, $nomeEsame);
		$statement->execute();
		$result = $statement->get_result();

		return $result->fetch_all(MYSQLI_ASSOC);

	}
	
	public function getParametroNonOrdinario($codSettore, $nomeEsame){
		$statement = $this->db->prepare('SELECT valore, unita, tipo, nome_vincolo, sesso FROM parametri WHERE codSet_es = ? AND nome_es = ? AND nome_vincolo IS NOT NULL');
		$statement->bind_param("is", $codSettore, $nomeEsame);
		$statement->execute();
		$result = $statement->get_result();

		return $result->fetch_all(MYSQLI_ASSOC);

	}

	public function getPrezziEsami(){
		$statement = $this->db->prepare("SELECT l.*, listini.nome AS nome_listino, settori_analitici.nome AS nome_settore FROM prezzi_esami l JOIN listini ON l.codListino = listini.codListino JOIN settori_analitici ON l.codSet_es = settori_analitici.codSet");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);

	}

	public function insertPrezzoEsame($listino, $settore, $nome, $valore){
		$statement = $this->db->prepare('INSERT INTO prezzi_esami (codListino, codSet_es, nome_es, valore) VALUES (?, ?, ?, ?)');
		$statement->bind_param('iisd', $listino, $settore, $nome, $valore);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}

	public function getProduttori(){
		$statement = $this->db->prepare("SELECT * FROM produttori");
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);

	}

	public function insertProduttore($nome){
		$statement = $this->db->prepare('INSERT INTO produttori (nome) VALUES (?)');
		$statement->bind_param('s', $nome);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}


	public function getProduttoreByName($name){
		$statement = $this->db->prepare("SELECT * FROM produttori WHERE nome = ?");
		$statement->bind_param('s', $name);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function checkCliente($CF){
		$statement = $this->db->prepare("SELECT * FROM clienti WHERE CF = ?");
		$statement->bind_param('s', $CF);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function checkInfermiere($CF){
		$statement = $this->db->prepare("SELECT * FROM infermieri WHERE CF = ?");
		$statement->bind_param('s', $CF);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function checkMedico($CF){
		$statement = $this->db->prepare("SELECT * FROM medici WHERE CF = ?");
		$statement->bind_param('s', $CF);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function checkTecnico($CF){
		$statement = $this->db->prepare("SELECT * FROM tecnici_di_laboratorio WHERE CF = ?");
		$statement->bind_param('s', $CF);
		$statement->execute();
		$result = $statement->get_result();
		
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	public function checkAll($CF){
		if ($this->checkCliente($CF)==0 && $this->checkInfermiere($CF)==0 && $this->checkMedico($CF)==0 && $this->checkTecnico($CF)==0){
			return 0;
		}
		else {
			return 1;
		}
	}

	public function aggiornaValore($aggiornaValore , $IDlistino, $IDsettore, $nomeEsame){
		$statement = $this->db->prepare("UPDATE prezzi_esami 
										 SET valore = ? WHERE codListino = ? AND codSet_es = ? AND nome_es = ?");
		$statement->bind_param("iiis", $aggiornaValore , $IDlistino, $IDsettore, $nomeEsame);
		$statement->execute();
		echo "<meta http-equiv='refresh' content='0'>";
	}
}
?> 
