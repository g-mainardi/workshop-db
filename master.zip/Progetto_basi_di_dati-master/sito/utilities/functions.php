<?php

	function connect(){
		$connection = new mysqli('127.0.0.1', 'root', '', 'progetto_basi_di_dati');
		if($connection->connect_error){
			die('Error connecting to the database');
		}
		return $connection;
	}
	
?>