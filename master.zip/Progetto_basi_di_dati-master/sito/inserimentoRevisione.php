<?php

    require_once 'require.php'; 

    $SetParameters["titolo"] = "Revisioni";
    $SetParameters["file"] = "revisioni.php";
    $SetParameters["strumenti"] = $db->getStrumenti();
    $SetParameters["controlli_mensili"] = $db->getMensili();
    $SetParameters["cont_mens_nonPassate"] = $db->getMensiliNonPassate();
    $SetParameters["revisioni_annuali"] = $db->getAnnuali();
    $SetParameters["rev_ann_nonPassate"] = $db->getAnnualiNonPassate();

    if(isset($_POST["mensile"]) && isset($_POST["seriale"]) && ($_POST["seriale"]!=0) && isset($_POST["data"]) && isset($_POST["rapporto"]) && isset($_POST["esito"])){
        $seriali = explode("  -  ", ($_POST["seriale"]));
        $db->insertRevisioneMensile($seriali[0], $seriali[1], $_POST["data"], $_POST["rapporto"], $_POST["esito"]);
    }

    if(isset($_POST["annuale"]) && isset($_POST["seriale"]) && ($_POST["seriale"]!=0) && isset($_POST["data"]) && isset($_POST["rapporto"]) && isset($_POST["esito"])){
        $seriali = explode("  -  ", ($_POST["seriale"]));
        $db->insertRevisioneAnnuale($seriali[0], $seriali[1], $_POST["data"], $_POST["esito"], $_POST["rapporto"]);
    }


    require("template/base.php");
?>