<?php

    require_once 'require.php';

    $SetParameters["titolo"] = "Lotti";
    $SetParameters["file"] = "lotti.php";
    $SetParameters["fornitori"] = $db->getFornitori();
    $SetParameters["tipi_di_materiale"] = $db->getMateriali();
    $SetParameters["lotti"] = $db->getLotti();

    if(isset($_POST["dataAcquisto"]) 
     && isset($_POST["IDmateriale"])
     && ($_POST["IDmateriale"]!=0)
     && isset($_POST["metodica"]) 
     && isset($_POST["quantita"]) 
     && isset($_POST["dataScadenza"]) 
     && isset($_POST["IDfornitore"]) 
     && ($_POST["IDfornitore"]!=0)
    ){
		$checkFornitore = $db->getFornitoreById($_POST['IDfornitore']);
		$error = false;
		if(sizeof($checkFornitore) <= 0){
			echo "Non esiste un fornitore con quel codice<br>";
			$error = true;
		}
		if($_POST['dataScadenza'] != "0000-00-00" && $_POST['dataAcquisto'] > $_POST['dataScadenza']){
			echo "Stai cercando di inserire dei prodotti già scaduti<br>";
			$error = true;
		}
		if(is_numeric($_POST['quantita'])){
			if(intval($_POST['quantita']) < 0){
				echo "Inserisci solo quantità positive<br>";
				$error = true;
			} else if(bccomp($_POST['quantita'], PHP_INT_MAX, 0) == 1){
				echo "Quantità inserita troppo grande<br>";
				$error = true;
			}
		} else {
			echo "La quantità deve essere un numero<br>";
			$error = true;
		}
		if($error == false){
			$db->insertLotto($_POST["dataAcquisto"], 
				$_POST["IDmateriale"], 
				$_POST["metodica"],
				$_POST["quantita"],
				$_POST["dataScadenza"], 
				$_POST["IDfornitore"], 
			);
		}
    }

    


 require("template/base.php");
?>