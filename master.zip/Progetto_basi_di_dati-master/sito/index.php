<?php

    require_once 'require.php';

    $SetParameters["titolo"] = "Home";
    $SetParameters["file"] = "homepage.php";
    require("template/base.php");

?>
