<?php

    require_once 'require.php';

    $SetParameters["titolo"] = "Materiali";
    $SetParameters["file"] = "materiali.php";
    $SetParameters["tipi_di_materiale"] = $db->getMateriali();
    $SetParameters["materialiEsauriti"] = $db->getMaterialiEsauriti();

   if(isset($_POST["nome"]) && isset($_POST["quantita"]) && isset($_POST["tipo_materiale"]) && isset($_POST["soglia"])){
        if($_POST["tipo_materiale"]=="reagente"){
            $reagente=1;
            $materialeSanitario=0;
            $db->insertMateriale($_POST["nome"], $reagente, $materialeSanitario, $_POST["quantita"], $_POST["soglia"]);
        }
        elseif($_POST["tipo_materiale"]=="materiale_sanitario"){
            $reagente=0;
            $materialeSanitario=1;
            $db->insertMateriale($_POST["nome"], $reagente, $materialeSanitario, $_POST["quantita"], $_POST["soglia"]);
        }     
    }

    if(isset ($_POST["aggiornaQuantita"]) && isset ($_POST["IDmateriale"])){
        $db->aggiornaQuantitaMateriale($_POST["aggiornaQuantita"], $_POST["IDmateriale"]);
    }



 require("template/base.php");
?>