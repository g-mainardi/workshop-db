<?php
    require_once 'require.php';

    $SetParameters["titolo"] = "Inserimento personale laboratorio";
    $SetParameters["file"] = "nuovoPersonaleLab.php";
    $SetParameters["tecnici_di_laboratorio"] = $db->getTecnici();
    $SetParameters["infermieri"] = $db->getInfermieri();
    
    if(isset($_POST["CFTecnico"]) && isset($_POST["nomeTecnico"]) && isset($_POST["cognomeTecnico"]) && isset($_POST["telefonoTecnico"]) && isset($_POST["mailTecnico"])){
		$error = false;
		if(strlen($_POST['nomeTecnico']) <= 0 || strlen($_POST['cognomeTecnico']) <= 0){
			echo "Nome e cognome non possono essere vuoti<br>";
			$error = true;
		}
		if(!filter_var($_POST['mailTecnico'], FILTER_VALIDATE_EMAIL)){
			echo "L'email non ha un giusto formato<br>";
			$error = true;
		}
		if(strlen($_POST["CFTecnico"]) != 16){
            echo strlen($_POST["CFTecnico"]);
			echo "Il codice fiscale è composto da esattamente 16 caratteri<br>";
			$error = true;
		}
		if(!is_numeric($_POST['telefonoTecnico'])){
			echo "Numero di telefono non valido<br>";
			$error = true;
		}
		if($db->checkAll(($_POST['CFTecnico']))!=0)
		{
			echo "CF gia presente nel database<br>";
			$error = true;
		}
		if(!$error){
			$db->insertTecnico($_POST["CFTecnico"], $_POST["nomeTecnico"], $_POST["cognomeTecnico"], $_POST["telefonoTecnico"], $_POST["mailTecnico"]);
		}
        
    }

    if(isset($_POST["CFInfermiere"]) && isset($_POST["nomeInfermiere"]) && isset($_POST["cognomeInfermiere"]) && isset($_POST["telefonoInfermiere"]) && isset($_POST["mailInfermiere"])){
		$error = false;
		if(strlen($_POST['nomeInfermiere']) <= 0 || strlen($_POST['cognomeInfermiere']) <= 0){
			echo "Nome e cognome non possono essere vuoti<br>";
			$error = true;
		}
		if(!filter_var($_POST['mailInfermiere'], FILTER_VALIDATE_EMAIL)){
			echo "L'email non ha un giusto formato<br>";
			$error = true;
		}
		if(strlen($_POST['CFInfermiere']) != 16){
			echo "Il codice fiscale è composto da esattamente 16 caratteri<br>";
			$error = true;
		}
		if(!is_numeric($_POST['telefonoInfermiere'])){
			echo "Numero di telefono non valido<br>";
			$error = true;
		}
		if($db->checkAll(($_POST['CFInfermiere']))!=0)
		{
			echo "CF gia presente nel database<br>";
			$error = true;
		}
		if(!$error){
			$db->insertInfermiere($_POST["CFInfermiere"], $_POST["nomeInfermiere"], $_POST["cognomeInfermiere"], $_POST["telefonoInfermiere"], $_POST["mailInfermiere"]);
		}

    }

 require("template/base.php");
?>